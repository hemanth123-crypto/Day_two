# AI-Powered Agriculture Crop Advisory Assistant — Design Document

## 1. System Philosophy & Motivation

Agricultural decision-making is characterized by high uncertainty, regional heterogeneity, and interdependent ecological variables (soil chemistry, microclimates, irrigation capacity, seasonal shifts). While agricultural research institutes and governmental extension services possess extensive historical records, rural practitioners, agronomists, and farmers struggle with information retrieval and context-aware synthesis.

Generic Large Language Models (LLMs) suffer from severe hallucinations when generating numerical agronomic recommendations, lack verifiable ground truth against specific agro-climatic zones, and cannot reliably extrapolate numerical yields. Conversely, isolated statistical regressions fail to interpret conversational, nuanced farmer queries or explain the causal rationale behind recommendations.

The **AI-Powered Agriculture Crop Advisory Assistant** bridges this divide through a **deterministic, hybrid decision-support architecture**:
1. **Dense + Sparse Hybrid RAG** for grounded retrieval of historical agricultural cases.
2. **Classical Machine Learning (Random Forest)** for robust, bounded numerical yield regression and suitability classification.
3. **Multi-Agent Orchestration** for separation of concerns across agronomic validation, risk auditing, and reasoning.
4. **Multi-tier Guardrails & LLM-as-a-Judge** to guarantee safety, domain scope adherence, and evidence citation.

---

## 2. Core Architectural Decisions & Rationales

### 2.1 Why RAG (Retrieval-Augmented Generation)?
- **Grounding in Historical Reality:** Agricultural advice must reflect verified farm trial outputs, regional soil surveys, and government yield statistics. RAG forces advisory responses to cite concrete historical cases rather than generating synthetic or hallucinated assertions.
- **Zero Hallucinated Inputs:** By feeding historical records into downstream recommendation agents, the system grounds every suggested crop in historical precedent ($Yield$, $Area$, $Rainfall$, $NPK$).
- **Updateability without Re-training:** When new seasonal harvest records arrive, they are vectorized and indexed into the datastore immediately without re-training foundation LLMs.

### 2.2 Why FAISS for Vector Search?
- **Sub-millisecond Latency on CPU:** Facebook AI Similarity Search (`FAISS`) provides optimized C++ SIMD vector distance calculations (`IndexFlatIP` with normalized vectors for Cosine Similarity). It performs similarity queries over thousands of agricultural cases in $< 2$ milliseconds without requiring an external database cluster.
- **Self-Contained & Air-Gapped Deployment:** FAISS indexes serialize directly into portable binary files (`indexes/faiss_index.bin`), removing cloud dependencies or managed vector DB costs.

### 2.3 Why Hybrid Search (Dense Semantic + Sparse Keyword)?
- **Dense SVD/TF-IDF Vector Retrieval** captures semantic similarity, intent synonyms, and broad context matching across variable descriptions.
- **Sparse Inverted Keyword Index (BM25-style TF-IDF)** captures exact agronomic terminology, numerical tokens ("pH 6.5", "Kharif", "Barley", "Andhra Pradesh"), and crop taxonomy that dense embeddings often smooth over.
- **Reciprocal Rank Fusion (RRF):** Combining both rankings with standard parameter $k=60$ ($RRF\_Score = \sum \frac{1}{k + rank_i}$) balances conceptual matching with exact keyword precision, drastically reducing false positives.

### 2.4 Why Metadata Filtering?
- Agricultural decisions are subject to **hard physical constraints**. For example, a farmer in *Rajasthan* during the *Rabi* season cannot plant flood-irrigated *Kharif Rice*, regardless of textual similarity in query wording.
- Pre-filtering and post-filtering by `Crop`, `Season`, `State`, and numerical ranges (e.g., $pH \in [6.0, 7.5]$, $Rainfall \ge 800\text{ mm}$) guarantees that retrieved precedents conform to regional agro-ecological boundaries.

### 2.5 Why Re-ranking?
- Hybrid retrieval generates an initial candidate set ($top\_k = 15$ to $30$).
- The re-ranking stage applies multi-factor agronomic scoring:
  $$\text{Score} = 0.50 \cdot \text{RRF} + 0.25 \cdot \text{Soil\_Similarity} + 0.15 \cdot \text{Weather\_Similarity} + 0.10 \cdot \text{Yield\_Decile}$$
- This guarantees that cases with both high textual relevance and high agricultural viability surface to the top of the evidence chain.

### 2.6 Why Classical Machine Learning for Yield Prediction (vs. LLMs)?
- **No Hallucinated Numbers:** LLMs are notorious for fabricating numerical values, floating-point statistics, and uncalibrated confidence scores.
- **Bounded Agronomic Physics:** A `RandomForestRegressor` trained on historical inputs ($N, P, K, pH, Temperature, Rainfall, Area, Fertilizer, Pesticide$) operates strictly within the distribution of empirical agricultural yields.
- **Tree Variance for Confidence Intervals:** By evaluating individual decision tree predictions across the forest ($T=100$), the system calculates exact standard errors and empirical 80% confidence intervals ($\hat{y} \pm 1.28 \cdot \sigma_{\text{trees}}$), giving farmers transparent risk bounds.
- **Computational Efficiency:** Inference takes $< 5$ milliseconds on modest hardware with zero GPU requirement.

### 2.7 Why Multi-Agent Architecture?
- **Single Prompt LLMs are Fragile:** Asking a single LLM prompt to classify intent, extract 10 parameters, search a database, calculate risk, forecast yields, evaluate safety, and format markdown leads to context drift, missed constraints, and hallucination.
- **Separation of Concerns:** The 8-agent pipeline enforces strict contractual boundaries:
  1. *Guardrail Agent:* Sanitizes inputs and filters adversarial injections.
  2. *Query Classifier Agent:* Parses intent and extracts structured agricultural parameters.
  3. *Retrieval Agent:* Executes hybrid search with metadata filters.
  4. *Recommendation Agent:* Ranks viable crops based exclusively on retrieved evidence.
  5. *Risk Analysis Agent:* Evaluates soil and climate stress (salinity, drought, nutrient deficiency).
  6. *Yield Prediction Agent:* Executes the ML regressor with tree-ensemble uncertainty bounds.
  7. *Impact Analysis Agent:* Quantifies feature importance and environmental sensitivity.
  8. *Validation Agent (LLM Judge):* Verifies groundedness against retrieved cases before dispatch.

### 2.8 Why Guardrails?
- **Prompt Injection Defense:** Prevents adversarial actors from hijacking the advisor to give dangerous chemical/pesticide recipes or breaking system prompts ("ignore previous instructions").
- **Domain Scope Guardrail:** Politely declines non-agricultural queries (cryptocurrency, coding, general trivia) preserving API resources.
- **Agronomic Boundary Checking:** Rejects biologically impossible inputs (e.g., negative rainfall, pH of 19.0, or 10,000 kg/ha nitrogen fertilizer).
- **Output Safety & Disclaimers:** Ensures no guarantee of crop output is made, preventing legal liabilities from microclimatic anomalies or natural disasters.

### 2.9 Why labeled retrieval evaluation?
- **Automated Quality Governance:** Traditional unit tests verify code execution, but cannot verify whether synthesized advice faithfully reflects retrieved evidence.
- **Offline-Safe Deterministic Validator:** Checks responses across 4 dimensions:
  1. *Relevance:* Did the response answer the user's explicit question?
  2. *Groundedness:* Are all mentioned crops present in the retrieved historical cases?
  3. *Quality:* Does the response contain structured advice, risks, and next steps?
  4. *Safety:* Are proper disclaimers and boundaries respected?
- **Labeled retrieval metrics:** The administrator can run the benchmark against the local hybrid retriever. Precision@K, Recall@5, MRR, and Hit Rate@5 are calculated using the benchmark's relevant crop labels and saved for review. No external LLM provider is needed.

### 2.10 Why User Feedback Loop?
- Continuous model and RAG improvement requires capturing real-world utility. The system stores user ratings (1–5 stars), categorical tags, and qualitative feedback in `data/feedback/feedback.json`, allowing the offline pipeline to identify low-performing query classes and re-tune index weights.

### 2.11 Why FastAPI?
- Modern asynchronous ASGI framework with high throughput, native Pydantic v2 data validation, OpenAPI 3.0 auto-documentation, and low memory footprint.

### 2.12 Why Optional Docker?
- Academic evaluators, developers, and deployment teams work across diverse environments (Windows, macOS, Linux). Supporting pure virtualenv execution (`python run.py`) ensures zero-friction local setup without requiring hypervisors or Docker Desktop licenses, while `Dockerfile` and `docker-compose.yml` provide one-command containerization for enterprise clusters.

---

## 3. Engineering Trade-offs Matrix

| Design Dimension | Selected Approach | Alternative Considered | Trade-off Analysis & Rationale |
|---|---|---|---|
| **Vector Database** | **FAISS (In-Memory / Local)** | Qdrant / Pinecone / Milvus | External vector DBs introduce network latency, Docker dependencies, and SaaS API costs. FAISS achieves sub-2ms local queries with zero external infrastructure. |
| **Search Paradigm** | **Hybrid (Dense + Sparse RRF)** | Pure Vector Search | Pure vector search loses exact agronomic terms (e.g., "pH 6.5" or "Kharif"). Hybrid ensures exact keyword matching while preserving semantic generalization. |
| **Yield Modeling** | **Random Forest Regressor** | Neural Net / LLM Estimation | LLMs hallucinate numbers; deep learning overfits tabular data of moderate size ($N \sim 1500$). Random Forest handles non-linearities, missing variables, and yields robust tree-variance confidence intervals. |
| **Pipeline Control** | **Deterministic Orchestration** | Autonomous ReAct Agent Loop | Fully autonomous LLM loops can enter non-deterministic cycles, take 10+ seconds, and consume unbounded tokens. Deterministic pipelines guarantee sub-100ms response times and 100% reproducible execution. |
| **Deployment Mode** | **Self-Contained Local First** | Cloud-Native Serverless | Rural agricultural research centers often operate with limited internet bandwidth. Local offline execution ensures resilience and low operating cost. |

---

## 4. Failure Modes & Graceful Degradation

1. **Missing / Unconfigured OpenAI API Key:** The system automatically shifts to local template synthesis and deterministic rule-based LLM Judge evaluation. All search, ML, and guardrail features remain 100% functional.
2. **Missing Raw Dataset:** The system auto-generates 1,500 synthetic agronomic cases adhering to Indian agricultural agro-climatic distributions.
3. **Out-of-Distribution Agronomic Inputs:** The Risk Analysis Agent flags inputs exceeding 3 standard deviations from historical norms, warning the user rather than failing silently.
4. **Empty Retrieval Results:** If strict metadata filtering returns zero candidates, the system relaxes metadata constraints hierarchically (State $\rightarrow$ Season $\rightarrow$ Crop) while alerting the user to the relaxation.
