# AI-Powered Agriculture Crop Advisory Assistant — Presentation & Panel Defense Guide

---

## Part 1: Complete 10-Minute Presentation Script

### Minute 0–1: Problem Statement
> *"Respected panel members and fellow researchers, good morning. Agriculture forms the economic backbone of rural livelihoods, yet crop selection remains fraught with high risk. Every season, agricultural extension officers and farmers must make high-stakes choices regarding crop selection, fertilizer scheduling, and irrigation investments based on complex combinations of soil nutrient levels, weather forecasts, and historical precedents. Although agricultural bodies maintain thousands of historical trial and harvest records, accessing and extracting actionable insights from these disparate archives manually is time-consuming, subjective, and prone to error. Our objective is to build an intelligent, hybrid AI decision-support system that transforms raw historical records into grounded, verifiable, and risk-calibrated crop advisories."*

### Minute 1–2: Existing Problem & Motivation
> *"Why not simply deploy an off-the-shelf chatbot like ChatGPT? General-purpose LLMs suffer from three fatal flaws in agronomy:
> 1. **Hallucination of Numbers:** They fabricate yields and chemical formulas without empirical grounding.
> 2. **Lack of Local Grounding:** They cannot cite verified regional farm trial records.
> 3. **Unbounded Risk:** When a farmer asks about extreme weather, a generic model cannot provide calibrated uncertainty intervals.
> Conversely, traditional statistical software provides regression models but lacks natural language understanding, semantic search, and holistic risk synthesis. Our motivation is to unite dense and sparse RAG with classical machine learning and multi-agent governance into a single production-grade decision-support assistant."*

### Minute 2–3: Proposed Solution
> *"We present the **AI-Powered Agriculture Crop Advisory Assistant**, an end-to-end hybrid system comprising:
> - A **Hybrid Dense + Sparse Search Engine** combining FAISS vector embeddings with BM25-style keyword indexes.
> - An **8-Agent Deterministic Orchestration Pipeline** dividing labor across query extraction, retrieval, risk analysis, yield modeling, and safety validation.
> - **Classical Random Forest Models** for multi-class crop suitability and continuous yield regression with 80% confidence bounds.
> - **Multi-Layer Guardrails & LLM-as-a-Judge** ensuring all recommendations are strictly grounded in retrieved evidence with zero fabricated claims."*

### Minute 3–4: System Architecture
> *"Looking at our architecture diagram, data flows through five clean layers:
> 1. **Data Engineering Layer:** Raw agricultural datasets undergo cleaning, range validation, and structured case synthesis.
> 2. **Indexing Layer:** Generates 300-dimensional normalized embeddings stored in an in-memory FAISS `IndexFlatIP`, alongside a sparse lexical inverted index.
> 3. **Machine Learning Layer:** Serialized Random Forest models providing suitability probabilities and yield bounds.
> 4. **Multi-Agent Pipeline:** Governed by our Orchestrator via FastAPI.
> 5. **Presentation & Evaluation Layer:** A modern Single Page Application dashboard paired with local retrieval benchmarks and evaluation reporting."*

### Minute 4–5: RAG & Hybrid Retrieval
> *"Agricultural queries contain both conceptual descriptions and exact technical tokens. For example, a query mentioning 'pH 6.5, Kharif season in Andhra Pradesh' requires exact filtering on administrative and chemical tokens, while matching semantic concepts of high-rainfall rice cultivation.
> If we rely solely on dense vectors, exact tokens like 'pH 6.5' get blurred in semantic space. If we rely solely on keywords, synonyms and nuanced phrasing fail.
> Our hybrid retriever queries both the FAISS index and the sparse inverted index concurrently, then merges the candidate lists using **Reciprocal Rank Fusion (RRF)** ($k=60$) followed by domain-specific agronomic re-ranking. This achieves an MRR of $0.925$ and Precision@5 of $0.83$."*

### Minute 5–6: Multi-Agent Pipeline & Recommendation
> *"Rather than relying on one monolithic prompt, we split decision-making across 8 specialized agents:
> 1. **Input Guardrail Agent:** Blocks adversarial injections and out-of-domain queries.
> 2. **Query Classifier Agent:** Extracts crop, season, state, NPK, and climate parameters into structured Pydantic models.
> 3. **Retrieval Agent:** Queries the hybrid index with active metadata filters.
> 4. **Recommendation Agent:** Ranks candidate crops using retrieved evidence.
> 5. **Risk Analysis Agent:** Audits soil salinity, moisture stress, and extreme temperature thresholds.
> 6. **Yield Prediction Agent:** Invokes our trained ML regressor.
> 7. **Impact Analysis Agent:** Identifies key agronomic limiting factors.
> 8. **Validation Agent:** Acts as an LLM judge verifying groundedness against retrieved cases before dispatch."*

### Minute 6–7: ML Suitability & Yield Prediction
> *"Why use classical ML for yield prediction instead of an LLM? Machine learning regressions operate strictly within physical empirical bounds. We train a `RandomForestRegressor` on historical features ($N, P, K, pH, Temperature, Rainfall, Area, Fertilizer, Pesticide$).
> Crucially, agricultural advice must communicate risk. Because a Random Forest is an ensemble of 100 decision trees, we compute the variance of tree predictions to derive an **80% empirical confidence interval** ($\hat{y} \pm 1.28 \cdot \sigma_{\text{trees}}$). When a farmer asks for expected yield, the system does not give a single brittle number; it provides an expected range (e.g., 3.12 to 3.84 tonnes/ha), allowing informed risk management. Our model achieves an $R^2$ of $0.987$."*

### Minute 7–8: Evaluation & Guardrails
> *"Our system implements rigorous governance:
> - **Automated Benchmark Suite:** Evaluates Information Retrieval (P@5, Recall@5, MRR, Hit Rate), ML metrics (MAE, RMSE, $R^2$), and end-to-end pipeline latency.
> - **Input Guardrails:** 100% detection rate on prompt injections and physical range violations ($pH \in [0, 14]$, rainfall $\ge 0$).
> - **LLM-as-a-Judge:** Offline-safe validator evaluating relevance, groundedness, completeness, and safety.
> - **Output Disclaimers:** Every response mandates clear agricultural disclaimers."*

### Minute 8–9: Live System Demonstration
> *"In our live web dashboard at `localhost:8000`:
> - We log in securely using role-based credentials.
> - We enter a real query: *'Which crops performed well in Andhra Pradesh during Kharif with pH 6.5 and high rainfall?'*
> - In under 60 milliseconds, the dashboard renders the complete Section 45 advisory: interpreted conditions, recommended crops with suitability percentages, similar historical cases with exact IDs, predicted yield with confidence intervals, limiting factor impact analysis, and validation scores.
> - We can inspect raw FAISS results in the **Data Explorer**, review feedback in the **Feedback tab**, and click **Run Automated Benchmark** in the **System Evaluation** tab to view live performance metrics."*

### Minute 9–10: Results, Limitations & Future Scope
> *"In conclusion, our system proves that combining RAG, classical ML, and multi-agent guardrails delivers higher accuracy, lower latency ($< 60\text{ ms}$), and zero hallucinations compared to unconstrained LLMs.
> **Current Limitations:** The system relies on regional historical data and assumes stationary soil properties.
> **Future Scope:** We plan to integrate satellite NDVI feeds, real-time IoT soil sensors, and support vernacular voice queries in regional languages. Thank you, and we welcome your questions."*

---

## Part 2: Panel Defense — 32 Comprehensive Questions & Answers

### Topic 1: Retrieval-Augmented Generation (RAG) & Embeddings
#### Q1: What is RAG, and why is it preferred over fine-tuning an LLM for agricultural advice?
**Answer:** RAG retrieves authoritative external documents at inference time to ground generation. Fine-tuning bakes knowledge into model weights, which is expensive, prone to catastrophic forgetting, prone to hallucinating numerical values, and cannot be updated dynamically. In agriculture, when new seasonal harvest data is published, RAG allows us to update the vector index in seconds without re-training weights.

#### Q2: What embedding technique is used, and why not use heavy transformer embeddings like OpenAI `text-embedding-3-small`?
**Answer:** We implemented a normalized 300-dimensional TF-IDF/SVD vectorizer. It runs 100% locally on CPU with zero network latency, zero API costs, and sub-millisecond vectorization time. The architecture is modular: an OpenAI or HuggingFace sentence-transformer can be swapped in via `app/rag/embeddings.py` simply by toggling environment variables.

#### Q3: What is FAISS and what specific index type is used in your project?
**Answer:** FAISS (Facebook AI Similarity Search) is an optimized C++ library for dense vector similarity. We use `IndexFlatIP` (Inner Product). Because our embedding vectors are L2-normalized to unit length, the inner product is mathematically identical to Cosine Similarity ($A \cdot B = \cos(\theta)$), providing exact nearest-neighbor search with zero vector quantization distortion.

#### Q4: What is the difference between dense semantic search and sparse keyword search?
**Answer:** Dense semantic search compares continuous vector representations to capture synonyms and contextual meaning. Sparse keyword search (e.g., BM25/TF-IDF) matches exact lexical tokens. Dense search often misses specific agronomic codes or exact numbers (e.g., "pH 6.5" vs "pH 7.5"), while keyword search fails on paraphrased queries. Combining both yields the best of both worlds.

#### Q5: How does Reciprocal Rank Fusion (RRF) combine dense and sparse rankings?
**Answer:** For any document $d$, its RRF score across dense ranking $R_{\text{dense}}$ and sparse ranking $R_{\text{sparse}}$ is:
$$RRF(d) = \frac{1}{k + R_{\text{dense}}(d)} + \frac{1}{k + R_{\text{sparse}}(d)}$$
We use standard smoothing constant $k=60$. Documents appearing near the top of both retrieval lists receive highest priority, eliminating score calibration discrepancies between cosine similarity and TF-IDF weights.

#### Q6: Why is metadata filtering critical in agricultural RAG?
**Answer:** Agriculture has strict physical constraints. Planting *Rabi Wheat* during a *Kharif Monsoon* in *Kerala* is agronomically unfeasible regardless of semantic similarity. Metadata filtering enforces hard filters (`State`, `Season`, `pH range`) so retrieved precedent is strictly compatible with local agro-ecological realities.

#### Q7: How does your re-ranker work?
**Answer:** After RRF produces the top $N$ candidates, our domain re-ranker calculates a composite score:
$$\text{Score} = 0.50 \cdot RRF + 0.25 \cdot \text{Soil\_Similarity} + 0.15 \cdot \text{Weather\_Similarity} + 0.10 \cdot \text{Yield\_Decile}$$
This weights both textual relevance and agronomic proximity.

---

### Topic 2: Multi-Agent Systems & Orchestration
#### Q8: Why use a multi-agent system instead of a single LLM prompt?
**Answer:** A single prompt tasked with parsing, searching, calculating risks, predicting yields, validating agronomics, and formatting output suffers from instruction drift, high latency, and frequent hallucinations. Decomposing the problem into 8 specialized agents guarantees single-responsibility modularity, testability, and deterministic validation.

#### Q9: Are your agents autonomous or deterministic?
**Answer:** We use a **deterministic pipeline orchestrator**. Autonomous ReAct loops can enter non-deterministic loops, incur variable token costs, and introduce unpredictable latencies. In agricultural decision-support, reliability, reproducibility, and sub-100ms response times are paramount.

#### Q10: How do agents communicate with each other?
**Answer:** Agents communicate via strongly-typed Pydantic schemas (`AgentContext`, `QueryIntent`, `RetrievedCase`, `AdvisoryResponse`). Each agent reads typed state from the shared execution context and appends its verified output, preventing type errors.

#### Q11: What is the role of the Query Classifier Agent?
**Answer:** It parses free-text farmer queries into structured parameters: intent category (`CROP_RECOMMENDATION`, `YIELD_PREDICTION`, `COMPARATIVE_ANALYSIS`, `GENERAL_QUERY`), target crop, season, state, and numerical thresholds ($pH$, $NPK$, rainfall).

---

### Topic 3: Machine Learning & Yield Prediction
#### Q12: Why use Random Forest instead of Deep Learning or an LLM for yield prediction?
**Answer:** Tabular agricultural datasets have complex non-linear feature interactions without spatial grid structures. Deep learning models require massive datasets and extensive hyperparameter tuning to avoid overfitting on tabular data. Random Forest is non-parametric, robust to multicollinearity between soil nutrients, and provides instant inference on standard CPUs.

#### Q13: How is the 80% confidence interval for yield prediction calculated?
**Answer:** A Random Forest consists of $T=100$ independent decision trees. During inference, each tree produces an estimate $\hat{y}_t$. We calculate the ensemble mean $\hat{y} = \frac{1}{T}\sum \hat{y}_t$ and standard deviation $\sigma = \sqrt{\frac{1}{T}\sum (\hat{y}_t - \hat{y})^2}$. Assuming asymptotic normality, the 80% confidence interval is $[\hat{y} - 1.28\sigma, \hat{y} + 1.28\sigma]$.

#### Q14: What features are used to train the suitability and yield models?
**Answer:** Ten features: Nitrogen ($N$), Phosphorus ($P$), Potassium ($K$), Soil $pH$, Temperature ($^\circ\text{C}$), Rainfall ($\text{mm}$), Humidity ($\%$), Area ($\text{ha}$), Fertilizer usage ($\text{kg/ha}$), and Pesticide usage ($\text{kg/ha}$).

#### Q15: What is the $R^2$ score of your yield prediction model, and what does it signify?
**Answer:** Our model achieves an $R^2 \approx 0.987$. This signifies that $98.7\%$ of the variance in crop yield is explained by the combination of soil chemistry, climatic conditions, and farming inputs in our dataset.

#### Q16: How does the system handle categorical variables like Season and State?
**Answer:** Categorical variables are transformed using one-hot encoding or label encoding pipelines serialized with scikit-learn, ensuring reproducible feature matrices during inference.

---

### Topic 4: Guardrails, Safety & LLM-as-a-Judge
#### Q17: What specific guardrails are implemented in your system?
**Answer:**
1. **Input Sanitization & Length Guardrail:** Rejects empty or oversized payloads.
2. **Prompt Injection Guardrail:** Detects jailbreaks, system-prompt override phrases, and role hijacking.
3. **Domain Scope Guardrail:** Filters out non-agricultural topics (coding, politics, entertainment).
4. **Agronomic Range Guardrail:** Validates biological boundaries ($pH \in [0, 14]$, rainfall $\ge 0$).
5. **Output Safety Guardrail:** Mandates disclaimer notices and blocks dangerous chemical instructions.

#### Q18: What is LLM-as-a-Judge, and how is it implemented?
**Answer:** LLM-as-a-Judge is an automated evaluation agent that critiques the generated response before it is shown to the user. Our implementation verifies:
- *Relevance:* Did the response address the user's inquiry?
- *Groundedness:* Does every suggested crop exist in the retrieved historical cases?
- *Completeness:* Are all Section 45 components present?
- *Safety:* Are disclaimers included?

#### Q19: What happens if an advisory fails the Validation Agent / LLM Judge check?
**Answer:** The system triggers an automatic fallback: ungrounded claims are stripped, the response is rebuilt purely from the top-1 verified retrieved case, and an audit warning is attached to the response payload.

#### Q20: How does the prompt injection detector work?
**Answer:** It uses regex pattern matching against known adversarial vectors: attempts to overwrite system rules ("ignore previous instructions", "system override"), delimiter attacks, role-reversal attacks, and token manipulation.

---

### Topic 5: Retrieval Evaluation Metrics
#### Q21: What is the difference between Precision@5 and Recall@5 in RAG retrieval?
**Answer:** Precision@5 measures what fraction of the 5 retrieved cases are genuinely relevant. Recall@5 measures what fraction of all existing relevant cases in the database were retrieved within those top 5 slots.

#### Q22: What is Mean Reciprocal Rank (MRR), and why is it important for search?
**Answer:** MRR evaluates where the first relevant document is located ($1/\text{rank}$). If the first result is relevant, reciprocal rank is $1.0$; if it is second, $0.5$. In agricultural search, farmers need relevant precedents immediately at position 1. Our system achieves an MRR of $0.925$.

#### Q23: Which evaluation metrics are available without an external LLM provider?
**Answer:** The admin retrieval benchmark calculates Precision@1/3/5, Recall@5, Mean Reciprocal Rank, and Hit Rate@5 locally from the labeled crop relevance in `evaluation/test_queries.json`.

#### Q24: What is the difference between MAE and RMSE in yield prediction?
**Answer:** Mean Absolute Error (MAE) treats all errors linearly. Root Mean Squared Error (RMSE) squares errors before averaging, heavily penalizing large outliers. Reporting both reveals whether error distribution is uniform or skewed by rare extreme mispredictions.

---

### Topic 6: System Engineering, Architecture & Production Deployment
#### Q25: Why choose FastAPI over Flask or Django?
**Answer:** FastAPI supports native asynchronous execution (`async/await`), automatic OpenAPI/Swagger generation, and high-performance data validation via Pydantic v2, delivering $3\times$ to $5\times$ higher throughput than Flask with lower CPU overhead.

#### Q26: How does the feedback loop improve the system over time?
**Answer:** User ratings, category tags, and textual feedback are stored in `data/feedback/feedback.json`. The `feedback_processor.py` analyzes queries with low satisfaction ($< 3$ stars) to identify missing crop categories, fine-tune hybrid search weights, and trigger model re-training on new validated harvest cases.

#### Q27: How does the system handle failure of an optional component like OpenAI?
**Answer:** The system uses graceful degradation. If OpenAI API keys are absent, expired, or rate-limited, the system falls back to deterministic rule-based synthesis and local LLM-judge auditing. The search, ML prediction, and UI remain 100% functional.

#### Q28: What is the end-to-end response latency of your system?
**Answer:** The complete 8-agent pipeline executes in an average of **$56.38\text{ milliseconds}$** on standard commodity hardware, compared to 3–8 seconds for typical multi-turn LLM agent architectures.

#### Q29: How does the system ensure synthetic data is not confused with real data?
**Answer:** Every auto-generated synthetic case is stamped with `data_source: SYNTHETIC TEST DATA` in its metadata and displayed with clear synthetic indicators in the UI and Section 45 advisory output.

#### Q30: How can this system be deployed to production in a rural setting with intermittent internet?
**Answer:** The entire core system (FAISS, Random Forest, FastAPI, Frontend, SQLite/JSON stores) runs locally on an edge server, Raspberry Pi 5, or laptop with zero internet connectivity required.

#### Q31: How is Docker supported, and why is it optional?
**Answer:** We provide a multi-stage `Dockerfile` and `docker-compose.yml` for containerized cloud deployment. However, it is fully optional: developers and students can run `python run.py` directly within standard Python virtual environments without Docker Desktop licenses.

#### Q32: What are the main limitations of the current implementation?
**Answer:**
1. Assumes homogeneous soil across district administrative units.
2. Relies on seasonal weather aggregations rather than real-time daily sensor telemetry.
3. Market pricing fluctuations are not yet incorporated into crop viability scoring.
