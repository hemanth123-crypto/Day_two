Canonical retrieval modules are in `app/rag/`; see `architecture/Architecture_Diagram.pdf`.
