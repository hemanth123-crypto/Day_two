Canonical agent modules are in `app/agents/`; see `design/Design_Document.pdf`.
