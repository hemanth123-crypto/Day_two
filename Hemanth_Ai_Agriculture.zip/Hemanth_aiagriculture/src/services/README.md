Canonical service modules are in `app/services/`.
