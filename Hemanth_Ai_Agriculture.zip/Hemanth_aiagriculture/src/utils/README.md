Canonical utilities are in `app/utils/`.
