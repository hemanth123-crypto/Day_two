Canonical API route modules are in `app/api/`; see `docs/API_Documentation.pdf`.
