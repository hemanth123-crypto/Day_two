"""Single-query LLM evaluation using Ragas and DeepEval with the configured judge."""

import asyncio
from typing import Any, Dict, List

from app.config.settings import settings


def _framework_result(status: str, reason: str, metrics: Dict[str, Any] | None = None) -> Dict[str, Any]:
    return {"status": status, "reason": reason, "metrics": metrics or {}}


def _score_value(result: Any) -> float:
    value = getattr(result, "value", getattr(result, "score", result))
    return round(float(value), 4)


def _error_summary(exc: Exception) -> str:
    """Return an actionable, bounded provider error without dumping response metadata."""
    message = str(exc)
    lowered = message.casefold()
    if "in_flight_budget" in lowered or "in-flight budget" in lowered:
        return "The judge provider's concurrent-request limit was reached. Evaluations are now run one at a time; retry this query."
    if "402" in lowered or "more credits" in lowered or "insufficient_quota" in lowered:
        return "The judge provider rejected the request because available credits are insufficient."
    if "max_tokens" in lowered or ("incomplete" in lowered and "output" in lowered):
        return "The judge response was truncated at its output-token limit."
    return message[:500]


def _run_ragas(query: str, response: str, contexts: List[str]) -> Dict[str, Any]:
    try:
        from openai import AsyncOpenAI
        from ragas.llms import llm_factory
        from ragas.metrics.collections import ContextUtilization, Faithfulness
    except ImportError as exc:
        return _framework_result("NOT INSTALLED", f"Install the Ragas dependency: {exc}")

    async def evaluate() -> Dict[str, Any]:
        client = AsyncOpenAI(
            api_key=settings.OPENAI_API_KEY,
            base_url=settings.OPENAI_BASE_URL,
            timeout=settings.LLM_TIMEOUT,
        )
        try:
            llm = llm_factory(settings.LLM_MODEL, provider="openai", client=client, max_tokens=1536)
            metrics = {
                "faithfulness": Faithfulness(llm=llm),
                "context_utilization": ContextUtilization(llm=llm),
            }
            outputs = []
            # A single OpenRouter-compatible account may have a strict in-flight
            # request budget. Avoid overlapping judge calls from RAGAS.
            for metric in metrics.values():
                try:
                    outputs.append(await metric.ascore(
                        user_input=query, response=response, retrieved_contexts=contexts
                    ))
                except Exception as exc:
                    outputs.append(exc)
            values: Dict[str, Any] = {}
            errors = []
            for (name, _), result in zip(metrics.items(), outputs):
                if isinstance(result, Exception):
                    reason = _error_summary(result)
                    values[name] = {"value": None, "reason": reason}
                    errors.append(f"{name}: {reason}")
                else:
                    values[name] = {"value": _score_value(result), "reason": str(getattr(result, "reason", ""))}
            scored = sum(item["value"] is not None for item in values.values())
            status = "COMPLETED" if scored == len(values) else "PARTIAL" if scored else "ERROR"
            return _framework_result(status, "; ".join(errors) if errors else "Ragas metrics completed.", values)
        except Exception as exc:
            return _framework_result("ERROR", _error_summary(exc))
        finally:
            await client.close()

    try:
        return asyncio.run(evaluate())
    except Exception as exc:
        return _framework_result("ERROR", _error_summary(exc))


def _run_deepeval(query: str, response: str, contexts: List[str]) -> Dict[str, Any]:
    try:
        from deepeval.metrics import ContextualRelevancyMetric, FaithfulnessMetric
        from deepeval.test_case import LLMTestCase
    except ImportError as exc:
        return _framework_result("NOT INSTALLED", f"Install the DeepEval dependency: {exc}")

    try:
        from deepeval.models import OpenAIModel
    except ImportError:
        # DeepEval 3.x exposes the OpenAI-compatible implementation as GPTModel.
        try:
            from deepeval.models.llms.openai_model import GPTModel as OpenAIModel
        except ImportError as exc:
            return _framework_result("NOT INSTALLED", f"DeepEval OpenAI model adapter is unavailable: {exc}")

    try:
        judge = OpenAIModel(
            model=settings.LLM_MODEL,
            api_key=settings.OPENAI_API_KEY,
            base_url=settings.OPENAI_BASE_URL,
            temperature=0,
            # Some OpenAI-compatible providers advertise a large default completion
            # limit that exceeds a user's remaining credit balance. Keep judge
            # responses concise while leaving ample room for structured reasoning.
            generation_kwargs={"timeout": settings.LLM_TIMEOUT, "max_tokens": 1024},
        )
        test_case = LLMTestCase(input=query, actual_output=response, retrieval_context=contexts)
        metric_instances = {
            "faithfulness": FaithfulnessMetric(model=judge, include_reason=False),
            "contextual_relevancy": ContextualRelevancyMetric(model=judge, include_reason=False),
        }
        values: Dict[str, Any] = {}
        errors = []
        for name, metric in metric_instances.items():
            try:
                metric.measure(test_case)
                values[name] = {
                    "value": _score_value(metric.score),
                    "reason": str(getattr(metric, "reason", "") or ""),
                }
            except Exception as exc:
                reason = _error_summary(exc)
                values[name] = {"value": None, "reason": reason}
                errors.append(f"{name}: {reason}")
        scored = sum(item["value"] is not None for item in values.values())
        status = "COMPLETED" if scored == len(values) else "PARTIAL" if scored else "ERROR"
        return _framework_result(status, "; ".join(errors) if errors else "DeepEval metrics completed.", values)
    except Exception as exc:
        return _framework_result("ERROR", _error_summary(exc))


def evaluate_with_ragas_and_deepeval(query: str, response: str, contexts: List[str]) -> Dict[str, Any]:
    """Run both judge frameworks serially; return scores and honest error states."""
    if not settings.has_openai():
        reason = "Configure OPENAI_API_KEY in .env to run LLM-as-a-judge metrics."
        return {
            "ragas": _framework_result("NOT CONFIGURED", reason),
            "deepeval": _framework_result("NOT CONFIGURED", reason),
        }
    if not response.strip():
        reason = "The advisory pipeline did not return an answer to evaluate."
        return {
            "ragas": _framework_result("NOT AVAILABLE", reason),
            "deepeval": _framework_result("NOT AVAILABLE", reason),
        }
    # Run one judge framework at a time so the four metric requests cannot
    # exhaust OpenRouter's per-account in-flight request budget.
    return {
        "ragas": _run_ragas(query, response, contexts),
        "deepeval": _run_deepeval(query, response, contexts),
    }
