"""
Authentication package for CropShield AI.
"""
