from __future__ import annotations
from datetime import datetime
from typing import Any, Dict, List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from backend.app.database import get_db, SessionLocal
from backend.app.models.course import Course
from backend.app.models.feedback import Feedback
from backend.app.models.user import User
from backend.app.services.search_service import _load_processed_courses
from backend.app.schemas.feedback import FeedbackCreate, FeedbackResponse
from backend.app.utils.auth import get_current_user_optional

router = APIRouter(prefix='/feedback', tags=['feedback'])


@router.post('', response_model=FeedbackResponse)
def submit_feedback(
    request: FeedbackCreate,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: Session = Depends(get_db)
):
    """
    Store student feedback for courses or recommendations in SQLite.
    Collects rating (1-5 stars), usefulness flag, optional comments,
    and automatically associates the active user if authenticated.
    """
    try:
        resolved_course_name = request.course_name
        if not resolved_course_name and request.course_id:
            course = db.query(Course).filter(Course.course_id == request.course_id).first()
            if course:
                resolved_course_name = course.course_name
            else:
                try:
                    courses = _load_processed_courses()
                    match = courses.loc[courses['course_id'].astype(str) == request.course_id, 'course_name']
                    if not match.empty:
                        resolved_course_name = str(match.iloc[0])
                except (FileNotFoundError, KeyError):
                    pass

        feedback = Feedback(
            user_id=current_user.id if current_user else None,
            username=current_user.username if current_user else None,
            course_id=request.course_id,
            course_name=resolved_course_name,
            rating=request.rating,
            useful=request.useful,
            comment=request.comment or '',
            created_at=datetime.utcnow()
        )
        db.add(feedback)
        db.commit()
        db.refresh(feedback)
        return FeedbackResponse(
            message='Feedback recorded successfully. Thank you for helping improve recommendations!',
            feedback_id=feedback.id,
            course_id=feedback.course_id,
            course_name=feedback.course_name,
            rating=feedback.rating,
            useful=feedback.useful,
            comment=feedback.comment or '',
            created_at=feedback.created_at,
            user_id=feedback.user_id,
            username=feedback.username,
        )
    except Exception as exc:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to record feedback: {str(exc)}")


@router.get('/stats')
def get_feedback_statistics(db: Session = Depends(get_db)):
    """
    Retrieve aggregated feedback metrics for evaluation:
    - Total submissions
    - Average rating
    - Positive usefulness percentage
    - Breakdown of ratings
    """
    all_feedback = db.query(Feedback).all()
    total = len(all_feedback)
    if total == 0:
        return {
            'total_feedback': 0,
            'average_rating': 0.0,
            'usefulness_rate': 0.0,
            'rating_distribution': {1: 0, 2: 0, 3: 0, 4: 0, 5: 0},
            'recent_feedback': [],
        }

    avg_rating = round(sum(f.rating for f in all_feedback) / total, 2)
    useful_count = sum(1 for f in all_feedback if f.useful)
    usefulness_rate = round((useful_count / total) * 100, 1)

    rating_dist = {i: 0 for i in range(1, 6)}
    for f in all_feedback:
        if f.rating in rating_dist:
            rating_dist[f.rating] += 1

    recent = [
        {
            'id': f.id,
            'user_id': f.user_id,
            'username': f.username or 'Student',
            'course_id': f.course_id,
            'course_name': f.course_name or (db.query(Course).filter(Course.course_id == f.course_id).first().course_name if f.course_id and db.query(Course).filter(Course.course_id == f.course_id).first() else None),
            'rating': f.rating,
            'useful': f.useful,
            'comment': f.comment,
            'created_at': f.created_at.isoformat() if f.created_at else None,
        }
        for f in sorted(all_feedback, key=lambda x: x.created_at or datetime.min, reverse=True)[:10]
    ]

    return {
        'total_feedback': total,
        'average_rating': avg_rating,
        'usefulness_rate': usefulness_rate,
        'rating_distribution': rating_dist,
        'recent_feedback': recent,
    }
