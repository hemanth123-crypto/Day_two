from __future__ import annotations

import json
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from backend.app.database import get_db
from backend.app.models.agent import AgentConversation, AgentMessage
from backend.app.models.user import User, UserSearchHistory
from backend.app.schemas.agent import AgentChatRequest, ImportRecommendationRequest
from backend.app.services.course_agent_service import answer_course_question, _course_context
from backend.app.services.llm_safety import UnsafeInputError, sanitize_user_text
from backend.app.services.search_service import search_courses
from backend.app.utils.auth import get_current_user

router = APIRouter(prefix='/agent', tags=['course_agent'])


def _decode_courses(value: str | None) -> list[dict]:
    try:
        decoded = json.loads(value or '[]')
        return decoded if isinstance(decoded, list) else []
    except (TypeError, ValueError):
        return []


def _serialize_message(message: AgentMessage) -> dict:
    return {
        'id': message.id,
        'role': message.role,
        'content': message.content,
        'courses': _decode_courses(message.course_context),
        'created_at': message.created_at,
    }


def _get_user_conversation(conversation_id: int, user_id: int, db: Session) -> AgentConversation:
    conversation = db.query(AgentConversation).filter(
        AgentConversation.id == conversation_id,
        AgentConversation.user_id == user_id,
    ).first()
    if conversation is None:
        raise HTTPException(status_code=404, detail='Conversation not found.')
    return conversation


def _import_legacy_searches(user: User, db: Session) -> None:
    """Make older recommendation searches available in the side agent."""
    existing_ids = {
        row[0] for row in db.query(AgentConversation.legacy_search_id)
        .filter(AgentConversation.user_id == user.id, AgentConversation.legacy_search_id.isnot(None))
        .all()
    }
    searches = db.query(UserSearchHistory).filter(
        UserSearchHistory.user_id == user.id
    ).order_by(UserSearchHistory.created_at.desc()).limit(100).all()
    changed = False
    for search in searches:
        if search.id in existing_ids:
            continue
        title = search.query.strip()[:255] or 'Saved course search'
        conversation = AgentConversation(
            user_id=user.id,
            title=title,
            source='recommendation',
            legacy_search_id=search.id,
            created_at=search.created_at,
            updated_at=search.created_at,
        )
        db.add(conversation)
        db.flush()
        db.add(AgentMessage(
            conversation_id=conversation.id,
            role='user',
            content=search.query,
            created_at=search.created_at,
        ))
        db.add(AgentMessage(
            conversation_id=conversation.id,
            role='assistant',
            content='This is a saved recommendation search. Ask a follow-up and I’ll search the course catalog for you.',
            created_at=search.created_at,
        ))
        changed = True
    if changed:
        db.commit()


@router.get('/conversations')
def list_agent_conversations(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _import_legacy_searches(current_user, db)
    conversations = db.query(AgentConversation).filter(
        AgentConversation.user_id == current_user.id
    ).order_by(AgentConversation.updated_at.desc()).limit(100).all()
    return [{
        'id': item.id,
        'title': item.title,
        'source': item.source,
        'updated_at': item.updated_at,
    } for item in conversations]


@router.get('/conversations/{conversation_id}')
def get_agent_conversation(
    conversation_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    conversation = _get_user_conversation(conversation_id, current_user.id, db)
    messages = db.query(AgentMessage).filter(
        AgentMessage.conversation_id == conversation.id
    ).order_by(AgentMessage.created_at.asc(), AgentMessage.id.asc()).all()
    return {
        'id': conversation.id,
        'title': conversation.title,
        'source': conversation.source,
        'messages': [_serialize_message(message) for message in messages],
    }


@router.post('/conversations/from-recommendation')
def import_recommendation(
    request: ImportRecommendationRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    try:
        query, _ = sanitize_user_text(request.query)
    except (ValueError, UnsafeInputError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    courses = [_course_context(course.model_dump()) for course in request.courses]
    linked_history = None
    if request.search_history_id:
        linked_history = db.query(UserSearchHistory).filter(
            UserSearchHistory.id == request.search_history_id,
            UserSearchHistory.user_id == current_user.id,
        ).first()
    conversation = AgentConversation(
        user_id=current_user.id,
        title=query[:255],
        source='recommendation',
        legacy_search_id=linked_history.id if linked_history else None,
    )
    db.add(conversation)
    db.flush()
    db.add_all([
        AgentMessage(
            conversation_id=conversation.id,
            role='user',
            content=query,
        ),
        AgentMessage(
            conversation_id=conversation.id,
            role='assistant',
            content=request.answer or 'Here are the courses and learning path found for your search. Ask me a follow-up about any of them.',
            course_context=json.dumps(courses),
        ),
    ])
    conversation.updated_at = datetime.utcnow()
    db.commit()
    return {'id': conversation.id, 'title': conversation.title, 'source': conversation.source}


@router.post('/chat')
def chat_with_course_agent(
    request: AgentChatRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    try:
        question, _ = sanitize_user_text(request.message.strip())
    except (ValueError, UnsafeInputError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    if not question:
        raise HTTPException(status_code=400, detail='Please enter a question.')

    if request.conversation_id:
        conversation = _get_user_conversation(request.conversation_id, current_user.id, db)
    else:
        conversation = AgentConversation(
            user_id=current_user.id,
            title=question[:255],
            source='chat',
        )
        db.add(conversation)
        db.flush()

    previous = db.query(AgentMessage).filter(
        AgentMessage.conversation_id == conversation.id
    ).order_by(AgentMessage.created_at.desc(), AgentMessage.id.desc()).limit(12).all()
    previous.reverse()
    history = [{'role': item.role, 'content': item.content} for item in previous]

    retrieval_terms = [question]
    for item in reversed(previous):
        if item.role == 'user' and len(retrieval_terms) < 3:
            retrieval_terms.append(item.content)
    # Reuse course context from earlier answers so short follow-ups like “what about
    # difficulty?” still refer to the courses the assistant just showed.
    for item in reversed(previous):
        if item.role == 'assistant':
            retrieval_terms.extend(course.get('course_name', '') for course in _decode_courses(item.course_context)[:5])
            if len(retrieval_terms) > 8:
                break
    profile_skills = _decode_courses(current_user.current_skills) if current_user.current_skills else []
    if profile_skills and all(isinstance(skill, str) for skill in profile_skills):
        retrieval_terms.extend(profile_skills[:8])
    if current_user.target_career:
        retrieval_terms.append(current_user.target_career)

    try:
        courses = search_courses(query=' '.join(filter(None, retrieval_terms)), top_k=8)
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f'Course search is temporarily unavailable: {exc}')
    courses = [_course_context(course) | {'description': course.get('description', '')} for course in courses]
    answer = answer_course_question(question, courses, history)

    db.add(AgentMessage(conversation_id=conversation.id, role='user', content=question))
    assistant_message = AgentMessage(
        conversation_id=conversation.id,
        role='assistant',
        content=answer,
        course_context=json.dumps([_course_context(course) for course in courses]),
    )
    db.add(assistant_message)
    conversation.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(assistant_message)
    return {
        'conversation_id': conversation.id,
        'answer': answer,
        'courses': [_course_context(course) for course in courses],
        'message': _serialize_message(assistant_message),
    }


@router.delete('/conversations/{conversation_id}')
def delete_agent_conversation(
    conversation_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    conversation = _get_user_conversation(conversation_id, current_user.id, db)
    db.query(AgentMessage).filter(AgentMessage.conversation_id == conversation.id).delete()
    db.delete(conversation)
    db.commit()
    return {'message': 'Conversation deleted.'}
