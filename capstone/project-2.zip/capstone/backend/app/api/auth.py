from __future__ import annotations

import json
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from backend.app.database import get_db
from backend.app.models.user import User
from backend.app.schemas.user import UserRegister, UserLogin, UserResponse, TokenResponse
from backend.app.utils.auth import (
    hash_password,
    verify_password,
    create_access_token,
    get_current_user,
    seed_default_users,
)

router = APIRouter(prefix='/auth', tags=['authentication'])


@router.post('/register', response_model=TokenResponse)
def register(req: UserRegister, db: Session = Depends(get_db)):
    """Register a new user account."""
    existing_user = db.query(User).filter(User.username == req.username).first()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username already taken. Please choose another username.",
        )

    existing_email = db.query(User).filter(User.email == req.email).first()
    if existing_email:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="An account with this email address already exists.",
        )

    user = User(
        username=req.username,
        email=req.email,
        password_hash=hash_password(req.password),
        role='user',
        full_name=req.full_name or req.username,
        current_skills=json.dumps(req.current_skills),
        target_career=req.target_career,
        created_at=datetime.utcnow(),
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    token = create_access_token(data={"sub": user.username, "role": user.role, "uid": user.id})
    return TokenResponse(
        access_token=token,
        token_type="bearer",
        user=UserResponse.model_validate(user),
    )


@router.post('/login', response_model=TokenResponse)
def login(req: UserLogin, db: Session = Depends(get_db)):
    """Authenticate user with username and password."""
    # Ensure seed accounts exist if database is fresh
    seed_default_users(db)

    user = db.query(User).filter(User.username == req.username).first()
    if not user or not verify_password(req.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password. Try 'admin'/'admin123' or 'student'/'student123'.",
        )

    token = create_access_token(data={"sub": user.username, "role": user.role, "uid": user.id})
    return TokenResponse(
        access_token=token,
        token_type="bearer",
        user=UserResponse.model_validate(user),
    )


@router.get('/me', response_model=UserResponse)
def get_me(current_user: User = Depends(get_current_user)):
    """Return the currently authenticated user's profile."""
    return UserResponse.model_validate(current_user)
