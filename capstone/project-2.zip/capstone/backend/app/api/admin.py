from __future__ import annotations

from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from backend.app.database import get_db
from backend.app.models.user import User, UserSearchHistory, UserBookmark, UserSavedPath
from backend.app.models.feedback import Feedback
from backend.app.models.course import Course
from backend.app.schemas.user import AdminUserItem, AdminRoleUpdate, AdminStatsResponse
from backend.app.utils.auth import get_current_admin

router = APIRouter(prefix='/admin', tags=['admin_management'])


@router.get('/stats', response_model=AdminStatsResponse)
def get_admin_system_stats(
    admin: User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    """Retrieve system-wide aggregated metrics accessible only to admins."""
    total_users = db.query(User).count()
    admin_count = db.query(User).filter(User.role == 'admin').count()
    user_count = db.query(User).filter(User.role == 'user').count()
    total_searches = db.query(UserSearchHistory).count()
    total_bookmarks = db.query(UserBookmark).count()
    total_feedback = db.query(Feedback).count()
    total_courses = db.query(Course).count()

    return AdminStatsResponse(
        total_users=total_users,
        admin_count=admin_count,
        user_count=user_count,
        total_searches=total_searches,
        total_bookmarks=total_bookmarks,
        total_feedback=total_feedback,
        total_courses=total_courses,
    )


@router.get('/users', response_model=List[AdminUserItem])
def list_all_users(
    admin: User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    """List all registered system users with activity statistics."""
    users = db.query(User).order_by(User.id.asc()).all()
    results = []
    for u in users:
        s_count = db.query(UserSearchHistory).filter(UserSearchHistory.user_id == u.id).count()
        b_count = db.query(UserBookmark).filter(UserBookmark.user_id == u.id).count()
        f_count = db.query(Feedback).filter(Feedback.user_id == u.id).count()
        results.append(
            AdminUserItem(
                id=u.id,
                username=u.username,
                email=u.email,
                role=u.role,
                full_name=u.full_name,
                created_at=u.created_at,
                search_count=s_count,
                bookmark_count=b_count,
                feedback_count=f_count,
            )
        )
    return results


@router.patch('/users/{user_id}/role', response_model=AdminUserItem)
def update_user_role(
    user_id: int,
    req: AdminRoleUpdate,
    admin: User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    """Change a user's role between 'admin' and 'user'."""
    if req.role not in ['admin', 'user']:
        raise HTTPException(status_code=400, detail="Role must be either 'admin' or 'user'.")

    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found.")

    if user.id == admin.id and req.role != 'admin':
        raise HTTPException(status_code=400, detail="Cannot demote your own admin account.")

    user.role = req.role
    db.commit()
    db.refresh(user)

    s_count = db.query(UserSearchHistory).filter(UserSearchHistory.user_id == user.id).count()
    b_count = db.query(UserBookmark).filter(UserBookmark.user_id == user.id).count()
    f_count = db.query(Feedback).filter(Feedback.user_id == user.id).count()

    return AdminUserItem(
        id=user.id,
        username=user.username,
        email=user.email,
        role=user.role,
        full_name=user.full_name,
        created_at=user.created_at,
        search_count=s_count,
        bookmark_count=b_count,
        feedback_count=f_count,
    )


@router.delete('/users/{user_id}')
def delete_user(
    user_id: int,
    admin: User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    """Delete a user account and associated personal data."""
    if user_id == admin.id:
        raise HTTPException(status_code=400, detail="Cannot delete your own admin account.")

    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found.")

    db.delete(user)
    db.commit()
    return {"message": f"User '{user.username}' deleted successfully."}


@router.get('/feedback')
def list_all_feedback_for_admin(
    admin: User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    """List all student feedback entries across all users for administrative moderation."""
    feedbacks = db.query(Feedback).order_by(Feedback.created_at.desc()).all()
    return [
        {
            "id": f.id,
            "user_id": f.user_id,
            "username": f.username or "Anonymous",
            "course_id": f.course_id,
            "rating": f.rating,
            "useful": f.useful,
            "comment": f.comment,
            "created_at": f.created_at.isoformat() if f.created_at else None,
        }
        for f in feedbacks
    ]


@router.delete('/feedback/{feedback_id}')
def delete_feedback(
    feedback_id: int,
    admin: User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    """Moderate and remove a feedback entry."""
    fb = db.query(Feedback).filter(Feedback.id == feedback_id).first()
    if not fb:
        raise HTTPException(status_code=404, detail="Feedback entry not found.")
    db.delete(fb)
    db.commit()
    return {"message": "Feedback deleted successfully."}
