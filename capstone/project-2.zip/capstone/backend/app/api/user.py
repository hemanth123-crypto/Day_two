from __future__ import annotations

import json
from datetime import datetime
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from backend.app.database import get_db
from backend.app.models.user import User, UserSearchHistory, UserBookmark, UserSavedPath
from backend.app.models.feedback import Feedback
from backend.app.models.course import Course
from backend.app.services.search_service import _load_processed_courses
from backend.app.schemas.user import (
    UserSearchHistoryCreate,
    UserSearchHistoryResponse,
    UserBookmarkCreate,
    UserBookmarkResponse,
    UserSavedPathCreate,
    UserSavedPathResponse,
    UserProfileUpdate,
    UserResponse,
)
from backend.app.utils.auth import get_current_user

router = APIRouter(prefix='/user', tags=['user_data'])


@router.put('/profile', response_model=UserResponse)
def update_user_profile(
    req: UserProfileUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Save the authenticated user's current skills and target career."""
    current_user.current_skills = json.dumps(req.current_skills)
    current_user.target_career = req.target_career
    db.commit()
    db.refresh(current_user)
    return UserResponse.model_validate(current_user)


# -------------------------------------------------------------
# Search History (User-isolated)
# -------------------------------------------------------------

@router.get('/history', response_model=List[UserSearchHistoryResponse])
def get_user_search_history(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Retrieve search history belonging strictly to the authenticated user."""
    items = (
        db.query(UserSearchHistory)
        .filter(UserSearchHistory.user_id == current_user.id)
        .order_by(UserSearchHistory.created_at.desc())
        .limit(50)
        .all()
    )
    return [UserSearchHistoryResponse.model_validate(item) for item in items]


@router.post('/history', response_model=UserSearchHistoryResponse)
def add_user_search_history(
    req: UserSearchHistoryCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Record a search inquiry under the authenticated user's account."""
    record = UserSearchHistory(
        user_id=current_user.id,
        query=req.query,
        career=req.career,
        skills=req.skills,
        created_at=datetime.utcnow(),
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return UserSearchHistoryResponse.model_validate(record)


@router.delete('/history')
def clear_user_search_history(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Clear all search history records for the authenticated user."""
    db.query(UserSearchHistory).filter(UserSearchHistory.user_id == current_user.id).delete()
    db.commit()
    return {"message": "Search history cleared for current user."}


# -------------------------------------------------------------
# Bookmarks / Saved Courses (User-isolated)
# -------------------------------------------------------------

@router.get('/bookmarks', response_model=List[UserBookmarkResponse])
def get_user_bookmarks(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Retrieve bookmarked courses saved by the authenticated user."""
    items = (
        db.query(UserBookmark)
        .filter(UserBookmark.user_id == current_user.id)
        .order_by(UserBookmark.created_at.desc())
        .all()
    )
    return [UserBookmarkResponse.model_validate(item) for item in items]


@router.post('/bookmarks', response_model=UserBookmarkResponse)
def add_user_bookmark(
    req: UserBookmarkCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Bookmark a course for the authenticated user."""
    existing = (
        db.query(UserBookmark)
        .filter(
            UserBookmark.user_id == current_user.id,
            UserBookmark.course_id == req.course_id
        )
        .first()
    )
    if existing:
        return UserBookmarkResponse.model_validate(existing)

    bookmark = UserBookmark(
        user_id=current_user.id,
        course_id=req.course_id,
        course_name=req.course_name,
        organization=req.organization,
        difficulty=req.difficulty,
        rating=req.rating,
        created_at=datetime.utcnow(),
    )
    db.add(bookmark)
    db.commit()
    db.refresh(bookmark)
    return UserBookmarkResponse.model_validate(bookmark)


@router.delete('/bookmarks/{course_id}')
def delete_user_bookmark(
    course_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Remove a course from the authenticated user's bookmarks."""
    deleted_count = (
        db.query(UserBookmark)
        .filter(
            UserBookmark.user_id == current_user.id,
            UserBookmark.course_id == course_id
        )
        .delete()
    )
    db.commit()
    if deleted_count == 0:
        raise HTTPException(status_code=404, detail="Bookmark not found.")
    return {"message": "Bookmark removed successfully."}


# -------------------------------------------------------------
# Saved Learning Paths (User-isolated)
# -------------------------------------------------------------

@router.get('/learning-paths', response_model=List[UserSavedPathResponse])
def get_user_saved_paths(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Retrieve saved learning paths belonging to the authenticated user."""
    paths = (
        db.query(UserSavedPath)
        .filter(UserSavedPath.user_id == current_user.id)
        .order_by(UserSavedPath.created_at.desc())
        .all()
    )
    return [UserSavedPathResponse.model_validate(p) for p in paths]


@router.post('/learning-paths', response_model=UserSavedPathResponse)
def save_user_learning_path(
    req: UserSavedPathCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Save a personalized learning path to the user's account."""
    record = UserSavedPath(
        user_id=current_user.id,
        title=req.title,
        target_career=req.target_career,
        path_json=req.path_json,
        created_at=datetime.utcnow(),
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return UserSavedPathResponse.model_validate(record)


@router.delete('/learning-paths/{path_id}')
def delete_user_learning_path(
    path_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Delete a saved learning path belonging to the authenticated user."""
    deleted = (
        db.query(UserSavedPath)
        .filter(
            UserSavedPath.id == path_id,
            UserSavedPath.user_id == current_user.id
        )
        .delete()
    )
    db.commit()
    if deleted == 0:
        raise HTTPException(status_code=404, detail="Saved path not found.")
    return {"message": "Learning path deleted successfully."}


# -------------------------------------------------------------
# User Personal Feedback
# -------------------------------------------------------------

@router.get('/feedback')
def get_user_feedback(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Retrieve feedback submitted by this specific user."""
    items = (
        db.query(Feedback)
        .filter(Feedback.user_id == current_user.id)
        .order_by(Feedback.created_at.desc())
        .all()
    )
    course_ids = {item.course_id for item in items if item.course_id}
    course_names = {
        course.course_id: course.course_name
        for course in db.query(Course).filter(Course.course_id.in_(course_ids)).all()
    } if course_ids else {}
    if course_ids:
        # Recommendations use the processed CSV as their source of truth; it
        # can contain courses that have not been copied into the SQL table.
        try:
            courses = _load_processed_courses()
            catalog_names = courses.loc[courses['course_id'].astype(str).isin(course_ids), ['course_id', 'course_name']]
            course_names.update(dict(zip(catalog_names['course_id'].astype(str), catalog_names['course_name'])))
        except (FileNotFoundError, KeyError):
            pass
    return [
        {
            "id": f.id,
            "course_id": f.course_id,
            # Older feedback rows may not have stored the course name. Resolve
            # it from the course catalog so the dashboard can identify it.
            "course_name": f.course_name or course_names.get(f.course_id),
            "rating": f.rating,
            "useful": f.useful,
            "comment": f.comment,
            "created_at": f.created_at.isoformat() if f.created_at else None,
        }
        for f in items
    ]
