from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import text

from backend.app.api import courses, recommendations, skills, learning_path, feedback, auth, user, admin, agent
from backend.app.config import APP_NAME, DEBUG
from backend.app.database import Base, engine, SessionLocal
from backend.app.models import Course, Feedback, User as UserModel, UserSearchHistory, UserBookmark, UserSavedPath
from backend.app.utils.auth import seed_default_users
from backend.app.utils.logging import RequestLoggingMiddleware, logger

# Create all database tables
Base.metadata.create_all(bind=engine)

# Safely check and add columns to feedback table if needed
def _migrate_and_seed():
    try:
        with engine.connect() as conn:
            for col, col_type in [('user_id', 'INTEGER'), ('username', 'VARCHAR(64)'), ('course_name', 'VARCHAR(255)')]:
                try:
                    conn.execute(text(f"ALTER TABLE feedback ADD COLUMN {col} {col_type}"))
                    conn.commit()
                except Exception:
                    pass
            for col, col_type, default in [
                ('current_skills', 'TEXT', "'[]'"),
                ('target_career', 'VARCHAR(128)', 'NULL'),
            ]:
                try:
                    conn.execute(text(f"ALTER TABLE users ADD COLUMN {col} {col_type} DEFAULT {default}"))
                    conn.commit()
                except Exception:
                    pass
    except Exception as e:
        logger.warning(f"Database migration check warning: {e}")

    try:
        db = SessionLocal()
        seed_default_users(db)
        db.close()
    except Exception as e:
        logger.warning(f"User seeding warning: {e}")

_migrate_and_seed()

app = FastAPI(title=APP_NAME, version='1.0.0', debug=DEBUG)

@app.on_event('startup')
def startup_event():
    logger.info("Pre-warming models and search indexes on startup...")
    try:
        from backend.app.services.search_service import _load_processed_courses, _get_faiss_index
        from backend.app.services.embedding_service import get_embedding_model
        _load_processed_courses()
        _get_faiss_index()
        get_embedding_model()
        logger.info("Startup complete. Models and search indexes are warm.")
    except Exception as exc:
        logger.warning(f"Startup warmup notice: {exc}")

app.add_middleware(RequestLoggingMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)

# API Routers
app.include_router(auth.router, prefix='/api/v1')
app.include_router(user.router, prefix='/api/v1')
app.include_router(admin.router, prefix='/api/v1')
app.include_router(agent.router, prefix='/api/v1')
app.include_router(courses.router, prefix='/api/v1')
app.include_router(recommendations.router, prefix='/api/v1')
app.include_router(skills.router, prefix='/api/v1')
app.include_router(learning_path.router, prefix='/api/v1')
app.include_router(feedback.router, prefix='/api/v1')


@app.get('/api/v1/health')
def health_check():
    return {'status': 'ok', 'app': APP_NAME}


@app.get('/')
def root():
    return {'message': APP_NAME}
