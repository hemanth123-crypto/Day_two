from __future__ import annotations
import json
from datetime import datetime
from typing import Optional, List, Any
from pydantic import BaseModel, Field, EmailStr, ConfigDict, field_validator


class UserRegister(BaseModel):
    username: str = Field(..., min_length=3, max_length=64)
    email: EmailStr
    password: str = Field(..., min_length=6)
    full_name: Optional[str] = None
    role: Optional[str] = Field(default='user', description="'user' or 'admin'")
    current_skills: List[str] = Field(default_factory=list, max_length=100)
    target_career: Optional[str] = Field(default=None, max_length=128)


class UserLogin(BaseModel):
    username: str
    password: str


class UserResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    username: str
    email: str
    role: str
    full_name: Optional[str] = None
    current_skills: List[str] = Field(default_factory=list)
    target_career: Optional[str] = None
    created_at: datetime

    @field_validator('current_skills', mode='before')
    @classmethod
    def decode_current_skills(cls, value: Any) -> List[str]:
        if isinstance(value, str):
            try:
                value = json.loads(value)
            except (TypeError, ValueError):
                return []
        return value if isinstance(value, list) else []


class UserProfileUpdate(BaseModel):
    current_skills: List[str] = Field(default_factory=list, max_length=100)
    target_career: Optional[str] = Field(default=None, max_length=128)


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse


class UserSearchHistoryCreate(BaseModel):
    query: str
    career: Optional[str] = None
    skills: Optional[str] = None


class UserSearchHistoryResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    query: str
    career: Optional[str] = None
    skills: Optional[str] = None
    created_at: datetime


class UserBookmarkCreate(BaseModel):
    course_id: str
    course_name: Optional[str] = None
    organization: Optional[str] = None
    difficulty: Optional[str] = None
    rating: Optional[float] = None


class UserBookmarkResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    course_id: str
    course_name: Optional[str] = None
    organization: Optional[str] = None
    difficulty: Optional[str] = None
    rating: Optional[float] = None
    created_at: datetime


class UserSavedPathCreate(BaseModel):
    title: str
    target_career: Optional[str] = None
    path_json: str  # JSON-serialized steps


class UserSavedPathResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    title: str
    target_career: Optional[str] = None
    path_json: str
    created_at: datetime


class AdminUserItem(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    username: str
    email: str
    role: str
    full_name: Optional[str] = None
    created_at: datetime
    search_count: int = 0
    bookmark_count: int = 0
    feedback_count: int = 0


class AdminRoleUpdate(BaseModel):
    role: str = Field(..., description="'user' or 'admin'")


class AdminStatsResponse(BaseModel):
    total_users: int
    admin_count: int
    user_count: int
    total_searches: int
    total_bookmarks: int
    total_feedback: int
    total_courses: int
