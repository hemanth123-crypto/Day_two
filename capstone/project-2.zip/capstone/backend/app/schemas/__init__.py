from backend.app.schemas.course import CourseBase, CourseResponse, CourseListResponse, CourseSearchRequest
from backend.app.schemas.skill import SkillAnalysisRequest, SkillGapResponse
from backend.app.schemas.recommendation import RecommendationRequest, RecommendationResponse, RecommendedCourse, LearningPathStep, ParsedQueryInfo
from backend.app.schemas.feedback import FeedbackCreate, FeedbackResponse
from backend.app.schemas.user import (
    UserRegister, UserLogin, UserResponse, TokenResponse,
    UserSearchHistoryCreate, UserSearchHistoryResponse,
    UserBookmarkCreate, UserBookmarkResponse,
    UserSavedPathCreate, UserSavedPathResponse,
    AdminUserItem, AdminRoleUpdate, AdminStatsResponse
)

__all__ = [
    'CourseBase',
    'CourseResponse',
    'CourseListResponse',
    'CourseSearchRequest',
    'SkillAnalysisRequest',
    'SkillGapResponse',
    'RecommendationRequest',
    'RecommendationResponse',
    'RecommendedCourse',
    'LearningPathStep',
    'ParsedQueryInfo',
    'FeedbackCreate',
    'FeedbackResponse',
    'UserRegister',
    'UserLogin',
    'UserResponse',
    'TokenResponse',
    'UserSearchHistoryCreate',
    'UserSearchHistoryResponse',
    'UserBookmarkCreate',
    'UserBookmarkResponse',
    'UserSavedPathCreate',
    'UserSavedPathResponse',
    'AdminUserItem',
    'AdminRoleUpdate',
    'AdminStatsResponse',
]
