from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, Field


class AgentChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=2000)
    conversation_id: Optional[int] = Field(default=None, gt=0)


class AgentCourse(BaseModel):
    course_id: str
    course_name: str
    organization: Optional[str] = None
    difficulty: Optional[str] = None
    rating: Optional[float] = None
    skills: Optional[str] = None
    url: Optional[str] = None


class ImportRecommendationRequest(BaseModel):
    query: str = Field(..., min_length=1, max_length=2000)
    answer: Optional[str] = Field(default=None, max_length=10000)
    courses: list[AgentCourse] = Field(default_factory=list, max_length=20)
    search_history_id: Optional[int] = Field(default=None, gt=0)


class AgentConversationSummary(BaseModel):
    id: int
    title: str
    source: str
    updated_at: datetime


class AgentMessageResponse(BaseModel):
    id: int
    role: str
    content: str
    courses: list[dict[str, Any]] = Field(default_factory=list)
    created_at: datetime
