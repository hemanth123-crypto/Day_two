"""Small local safety checks for text sent to and returned from the LLM."""
from __future__ import annotations

import re
from typing import Any, Iterable


MAX_QUERY_LENGTH = 2000

_INJECTION_PATTERNS = [
    re.compile(r"\b(?:ignore|disregard|forget|override|bypass)\b.{0,80}\b(?:previous|prior|above|system|developer|hidden|safety)\b.{0,30}\b(?:instruction|prompt|rule|message)s?\b", re.I | re.S),
    re.compile(r"\b(?:reveal|print|repeat|show|output)\b.{0,60}\b(?:system prompt|hidden instructions|developer message|api key|secret)s?\b", re.I | re.S),
    re.compile(r"<\s*/?\s*(?:system|assistant|developer|tool)\s*>", re.I),
    re.compile(r"\b(?:jailbreak|DAN mode|developer mode)\b", re.I),
    re.compile(r"\bact as\b.{0,50}\b(?:unrestricted|unfiltered|no rules|without limits)\b", re.I | re.S),
]

_PII_PATTERNS = {
    "email": re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.I),
    "ssn": re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
    "phone": re.compile(r"(?<!\w)(?:\+?\d[\d().\s-]{8,}\d)(?!\w)"),
}

# This is a narrow block list for explicit instructions to cause serious harm.
# It is a baseline check, not a general-purpose toxicity classifier.
_HARMFUL_OUTPUT_PATTERNS = [
    re.compile(r"\b(?:how to|instructions? to|steps to|make|build)\b.{0,80}\b(?:kill|murder|poison|bomb|explosive|weapon|shoot|stab)\b", re.I | re.S),
    re.compile(r"\b(?:how to|instructions? to|steps to)\b.{0,80}\b(?:self[- ]harm|suicide|hurt myself)\b", re.I | re.S),
]


class UnsafeInputError(ValueError):
    """Raised when user text contains a likely prompt-control instruction."""


def sanitize_user_text(value: str) -> tuple[str, set[str]]:
    """Reject likely prompt injections and redact common PII patterns."""
    if len(value) > MAX_QUERY_LENGTH:
        raise ValueError(f"Text must be {MAX_QUERY_LENGTH} characters or fewer.")
    if any(pattern.search(value) for pattern in _INJECTION_PATTERNS):
        raise UnsafeInputError("Text contains instructions that cannot be processed.")

    redacted: set[str] = set()
    sanitized = value
    for kind, pattern in _PII_PATTERNS.items():
        def replace(match: re.Match[str]) -> str:
            if kind == "phone" and sum(ch.isdigit() for ch in match.group()) < 10:
                return match.group()
            redacted.add(kind)
            return f"[{kind.upper()} REDACTED]"

        sanitized = pattern.sub(replace, sanitized)
    return sanitized, redacted


def unsafe_output_reason(text: str) -> str | None:
    """Return a generic rejection reason for harmful or PII-bearing output."""
    if any(pattern.search(text) for pattern in _HARMFUL_OUTPUT_PATTERNS):
        return "harmful_content"
    if any(pattern.search(text) for pattern in _PII_PATTERNS.values()):
        return "pii_detected"
    return None


def verify_grounded_answer(text: str, recommendations: Iterable[dict[str, Any]]) -> bool:
    """Reject answers that name a course absent from the retrieved catalog results.

    The model is instructed to use retrieved titles; this check catches likely
    invented course-title claims without trying to verify general prose.
    """
    allowed = {str(course.get("course_name", "")).strip().casefold()
               for course in recommendations if course.get("course_name")}
    if not allowed:
        return False
    # Course names are the only verifiable factual claims this small layer owns.
    # Remove allowed titles; a remaining explicit course-title phrase indicates
    # an ungrounded recommendation and should fall back to structured results.
    title_mentions = re.findall(r"\*\*([^*\n]{3,120})\*\*", text)
    return all(title.strip().casefold() in allowed for title in title_mentions)


def validate_course_ids(course_ids: Any, recommendations: Iterable[dict[str, Any]]) -> list[str] | None:
    """Accept only unique course IDs present in the retrieved recommendation set."""
    allowed = {str(course.get("course_id")) for course in recommendations if course.get("course_id")}
    if not isinstance(course_ids, list) or len(course_ids) > 5:
        return None
    if any(not isinstance(course_id, str) or course_id not in allowed for course_id in course_ids):
        return None
    if len(set(course_ids)) != len(course_ids):
        return None
    return course_ids
