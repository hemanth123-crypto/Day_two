from __future__ import annotations
from datetime import datetime
from sqlalchemy import Column, Integer, String, Text, Float, DateTime, ForeignKey
from sqlalchemy.orm import relationship

from backend.app.database import Base


class User(Base):
    __tablename__ = 'users'

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(64), unique=True, index=True, nullable=False)
    email = Column(String(128), unique=True, index=True, nullable=False)
    password_hash = Column(String(256), nullable=False)
    role = Column(String(32), nullable=False, default='user')  # 'admin' or 'user'
    full_name = Column(String(128), nullable=True)
    current_skills = Column(Text, nullable=False, default='[]')
    target_career = Column(String(128), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    # Relationships
    search_history = relationship('UserSearchHistory', back_populates='user', cascade='all, delete-orphan')
    bookmarks = relationship('UserBookmark', back_populates='user', cascade='all, delete-orphan')
    saved_paths = relationship('UserSavedPath', back_populates='user', cascade='all, delete-orphan')


class UserSearchHistory(Base):
    __tablename__ = 'user_search_history'

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    query = Column(String(512), nullable=False)
    career = Column(String(128), nullable=True)
    skills = Column(String(256), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    user = relationship('User', back_populates='search_history')


class UserBookmark(Base):
    __tablename__ = 'user_bookmarks'

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    course_id = Column(String(64), nullable=False, index=True)
    course_name = Column(String(255), nullable=True)
    organization = Column(String(255), nullable=True)
    difficulty = Column(String(64), nullable=True)
    rating = Column(Float, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    user = relationship('User', back_populates='bookmarks')


class UserSavedPath(Base):
    __tablename__ = 'user_saved_paths'

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    title = Column(String(255), nullable=False)
    target_career = Column(String(128), nullable=True)
    path_json = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    user = relationship('User', back_populates='saved_paths')
