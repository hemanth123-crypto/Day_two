from sqlalchemy import Column, Integer, String, Boolean, DateTime

from backend.app.database import Base


class Feedback(Base):
    __tablename__ = 'feedback'

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, nullable=True, index=True)
    username = Column(String(64), nullable=True, index=True)
    course_id = Column(String, nullable=True)
    course_name = Column(String(255), nullable=True)
    rating = Column(Integer, nullable=False)
    useful = Column(Boolean, default=True)
    comment = Column(String, nullable=True)
    created_at = Column(DateTime, nullable=False)
