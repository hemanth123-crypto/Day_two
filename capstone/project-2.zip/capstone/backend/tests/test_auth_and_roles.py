from fastapi.testclient import TestClient
from backend.app.main import app

client = TestClient(app)


def test_seed_accounts_login():
    # Admin login
    res = client.post('/api/v1/auth/login', json={'username': 'admin', 'password': 'admin123'})
    assert res.status_code == 200
    data = res.json()
    assert data['user']['role'] == 'admin'
    assert 'access_token' in data

    # Student login
    res_s = client.post('/api/v1/auth/login', json={'username': 'student', 'password': 'student123'})
    assert res_s.status_code == 200
    data_s = res_s.json()
    assert data_s['user']['role'] == 'user'
    assert 'access_token' in data_s


def test_admin_protected_routes():
    # 1. Unauthenticated request to admin endpoint -> 401
    r_unauth = client.get('/api/v1/admin/stats')
    assert r_unauth.status_code == 401

    # 2. Student user token to admin endpoint -> 403 Forbidden
    login_student = client.post('/api/v1/auth/login', json={'username': 'student', 'password': 'student123'}).json()
    student_token = login_student['access_token']
    r_forbidden = client.get('/api/v1/admin/stats', headers={'Authorization': f'Bearer {student_token}'})
    assert r_forbidden.status_code == 403

    # 3. Admin token to admin endpoint -> 200 OK
    login_admin = client.post('/api/v1/auth/login', json={'username': 'admin', 'password': 'admin123'}).json()
    admin_token = login_admin['access_token']
    r_ok = client.get('/api/v1/admin/stats', headers={'Authorization': f'Bearer {admin_token}'})
    assert r_ok.status_code == 200
    stats = r_ok.json()
    assert 'total_users' in stats
    assert 'admin_count' in stats
    assert stats['admin_count'] >= 1


def test_user_data_distinction_between_users():
    import random
    suffix = random.randint(10000, 99999)

    # Register Alice
    r_alice = client.post('/api/v1/auth/register', json={
        'username': f'alice_{suffix}',
        'email': f'alice_{suffix}@test.edu',
        'password': 'password123',
        'full_name': 'Alice Test',
    })
    assert r_alice.status_code == 200
    token_alice = r_alice.json()['access_token']

    # Register Bob
    r_bob = client.post('/api/v1/auth/register', json={
        'username': f'bob_{suffix}',
        'email': f'bob_{suffix}@test.edu',
        'password': 'password123',
        'full_name': 'Bob Test',
    })
    assert r_bob.status_code == 200
    token_bob = r_bob.json()['access_token']

    headers_alice = {'Authorization': f'Bearer {token_alice}'}
    headers_bob = {'Authorization': f'Bearer {token_bob}'}

    # Alice searches for "Deep Learning"
    client.post('/api/v1/user/history', json={'query': 'Deep Learning with PyTorch', 'career': 'ML Engineer'}, headers=headers_alice)
    # Alice bookmarks course_0000
    client.post('/api/v1/user/bookmarks', json={'course_id': 'course_0000', 'course_name': 'Python Basics'}, headers=headers_alice)

    # Bob searches for "Cloud DevOps"
    client.post('/api/v1/user/history', json={'query': 'Kubernetes on AWS', 'career': 'Cloud Engineer'}, headers=headers_bob)
    # Bob bookmarks course_0001
    client.post('/api/v1/user/bookmarks', json={'course_id': 'course_0001', 'course_name': 'AWS Cloud Fundamentals'}, headers=headers_bob)

    # Alice fetches her search history & bookmarks
    alice_hist = client.get('/api/v1/user/history', headers=headers_alice).json()
    alice_bm = client.get('/api/v1/user/bookmarks', headers=headers_alice).json()
    assert len(alice_hist) == 1
    assert alice_hist[0]['query'] == 'Deep Learning with PyTorch'
    assert len(alice_bm) == 1
    assert alice_bm[0]['course_id'] == 'course_0000'

    # Bob fetches his search history & bookmarks - MUST NOT contain Alice's data!
    bob_hist = client.get('/api/v1/user/history', headers=headers_bob).json()
    bob_bm = client.get('/api/v1/user/bookmarks', headers=headers_bob).json()
    assert len(bob_hist) == 1
    assert bob_hist[0]['query'] == 'Kubernetes on AWS'
    assert len(bob_bm) == 1
    assert bob_bm[0]['course_id'] == 'course_0001'

    # Alice clears her history
    client.delete('/api/v1/user/history', headers=headers_alice)
    alice_hist_after = client.get('/api/v1/user/history', headers=headers_alice).json()
    assert len(alice_hist_after) == 0

    # Bob's history is completely intact!
    bob_hist_still = client.get('/api/v1/user/history', headers=headers_bob).json()
    assert len(bob_hist_still) == 1
