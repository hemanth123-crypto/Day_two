import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import api from '../services/api';
import { User, AuthTokenResponse } from '../types';

interface AuthContextValue {
  user: User | null;
  token: string | null;
  loading: boolean;
  login: (username: string, password: string) => Promise<void>;
  register: (username: string, email: string, password: string, fullName: string | undefined, currentSkills: string[], targetCareer: string) => Promise<void>;
  updateProfile: (currentSkills: string[], targetCareer: string) => Promise<void>;
  logout: () => void;
  isAdmin: boolean;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  // Restore session from localStorage on mount
  useEffect(() => {
    const storedToken = localStorage.getItem('ucf_token');
    const storedUser = localStorage.getItem('ucf_user');
    if (storedToken && storedUser) {
      try {
        setToken(storedToken);
        setUser(JSON.parse(storedUser));
      } catch {
        localStorage.removeItem('ucf_token');
        localStorage.removeItem('ucf_user');
      }
    }
    setLoading(false);
  }, []);

  const persist = (data: AuthTokenResponse) => {
    localStorage.setItem('ucf_token', data.access_token);
    localStorage.setItem('ucf_user', JSON.stringify(data.user));
    setToken(data.access_token);
    setUser(data.user);
  };

  const login = useCallback(async (username: string, password: string) => {
    const res = await api.post<AuthTokenResponse>('/auth/login', { username, password });
    persist(res.data);
  }, []);

  const register = useCallback(async (
    username: string,
    email: string,
    password: string,
    fullName?: string,
    currentSkills: string[] = [],
    targetCareer = '',
  ) => {
    const res = await api.post<AuthTokenResponse>('/auth/register', {
      username,
      email,
      password,
      full_name: fullName,
      current_skills: currentSkills,
      target_career: targetCareer,
    });
    persist(res.data);
  }, []);

  const updateProfile = useCallback(async (currentSkills: string[], targetCareer: string) => {
    const res = await api.put<User>('/user/profile', {
      current_skills: currentSkills,
      target_career: targetCareer,
    });
    localStorage.setItem('ucf_user', JSON.stringify(res.data));
    setUser(res.data);
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem('ucf_token');
    localStorage.removeItem('ucf_user');
    // Also clear per-user search history key if present
    setToken(null);
    setUser(null);
  }, []);

  const value: AuthContextValue = {
    user,
    token,
    loading,
    login,
    register,
    updateProfile,
    logout,
    isAdmin: user?.role === 'admin',
    isAuthenticated: !!user,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>');
  return ctx;
}
