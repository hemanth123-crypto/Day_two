import { Bot, BookOpen, Clock3, MessageCircle, Plus, Send, Trash2, X } from 'lucide-react';
import { FormEvent, KeyboardEvent, useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import { useAuth } from '../contexts/AuthContext';

type AgentCourse = {
  course_id: string;
  course_name: string;
  organization?: string | null;
  difficulty?: string | null;
  rating?: number | null;
  skills?: string | null;
  url?: string | null;
};

type AgentMessage = {
  id: number | string;
  role: 'user' | 'assistant';
  content: string;
  courses?: AgentCourse[];
  created_at?: string;
};

type AgentConversation = {
  id: number;
  title: string;
  source: string;
  updated_at: string;
};

const quickQuestions = [
  'Show me beginner courses for Python',
  'Which courses help with cloud engineering?',
  'Compare courses for machine learning',
];

export default function CourseAgent() {
  const navigate = useNavigate();
  const { token } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const [loadingConversation, setLoadingConversation] = useState(false);
  const [sending, setSending] = useState(false);
  const [conversationId, setConversationId] = useState<number | null>(null);
  const [conversations, setConversations] = useState<AgentConversation[]>([]);
  const [messages, setMessages] = useState<AgentMessage[]>([]);
  const [input, setInput] = useState('');
  const [error, setError] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, sending]);

  if (!token) return null;

  const loadConversations = async () => {
    setLoadingHistory(true);
    try {
      const response = await api.get<AgentConversation[]>('/agent/conversations');
      setConversations(response.data);
      setError('');
    } catch (err: any) {
      setError(err?.response?.data?.detail || 'Could not load saved conversations.');
    } finally {
      setLoadingHistory(false);
    }
  };

  const openAgent = () => {
    setIsOpen(true);
    setShowHistory(false);
    void loadConversations();
  };

  const startNewConversation = () => {
    setConversationId(null);
    setMessages([]);
    setInput('');
    setError('');
    setShowHistory(false);
  };

  const openConversation = async (id: number) => {
    setLoadingConversation(true);
    setError('');
    try {
      const response = await api.get(`/agent/conversations/${id}`);
      setConversationId(id);
      setMessages(response.data.messages || []);
      setShowHistory(false);
    } catch (err: any) {
      setError(err?.response?.data?.detail || 'Could not open that conversation.');
    } finally {
      setLoadingConversation(false);
    }
  };

  const deleteConversation = async (id: number) => {
    try {
      await api.delete(`/agent/conversations/${id}`);
      setConversations((items) => items.filter((item) => item.id !== id));
      if (conversationId === id) startNewConversation();
    } catch (err: any) {
      setError(err?.response?.data?.detail || 'Could not delete that conversation.');
    }
  };

  const sendMessage = async (value = input) => {
    const message = value.trim();
    if (!message || sending) return;

    const optimistic: AgentMessage = { id: `local-${Date.now()}`, role: 'user', content: message };
    setMessages((items) => [...items, optimistic]);
    setInput('');
    setError('');
    setSending(true);
    try {
      const response = await api.post('/agent/chat', {
        message,
        conversation_id: conversationId,
      });
      const id = response.data.conversation_id as number;
      const answer: AgentMessage = response.data.message || {
        id: `answer-${Date.now()}`,
        role: 'assistant',
        content: response.data.answer,
        courses: response.data.courses,
      };
      setConversationId(id);
      setMessages((items) => [...items, answer]);
      void loadConversations();
    } catch (err: any) {
      setMessages((items) => items.filter((item) => item.id !== optimistic.id));
      setInput(message);
      setError(err?.response?.data?.detail || 'The course agent could not respond. Please try again.');
    } finally {
      setSending(false);
    }
  };

  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();
    void sendMessage();
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      void sendMessage();
    }
  };

  return (
    <div className="fixed bottom-5 right-24 z-50 flex flex-col items-end gap-3">
      {isOpen && (
        <section className="flex h-[min(76vh,640px)] w-[min(92vw,420px)] flex-col overflow-hidden rounded-3xl border border-brown-700 bg-slate-950 shadow-[0_24px_80px_rgba(0,0,0,0.75)]">
          <header className="flex items-center justify-between border-b border-brown-700 bg-brown-950/80 px-4 py-3">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-teal-700/30 text-teal-300">
                <Bot size={20} />
              </div>
              <div>
                <h2 className="text-sm font-bold text-brown-100">Course Assistant</h2>
                <p className="text-[11px] text-brown-400">Answers grounded in the course catalog</p>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => { setShowHistory((visible) => !visible); setError(''); }}
                aria-label="Show conversations"
                title="Conversations"
                className="rounded-lg p-2 text-brown-300 transition hover:bg-brown-800 hover:text-teal-300"
              >
                <Clock3 size={17} />
              </button>
              <button
                type="button"
                onClick={startNewConversation}
                aria-label="Start a new conversation"
                title="New conversation"
                className="rounded-lg p-2 text-brown-300 transition hover:bg-brown-800 hover:text-teal-300"
              >
                <Plus size={18} />
              </button>
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                aria-label="Close course assistant"
                className="rounded-lg p-2 text-brown-300 transition hover:bg-brown-800 hover:text-teal-300"
              >
                <X size={17} />
              </button>
            </div>
          </header>

          {showHistory ? (
            <div className="min-h-0 flex-1 overflow-y-auto p-3">
              <div className="mb-3 flex items-center justify-between px-1">
                <h3 className="text-xs font-bold uppercase tracking-wider text-brown-300">Saved conversations</h3>
                <button type="button" onClick={startNewConversation} className="text-xs font-semibold text-teal-300 hover:text-teal-200">New chat</button>
              </div>
              {loadingHistory ? (
                <p className="p-4 text-center text-xs text-brown-400">Loading conversations…</p>
              ) : conversations.length ? (
                <div className="space-y-2">
                  {conversations.map((conversation) => (
                    <div key={conversation.id} className="flex items-center gap-2 rounded-xl border border-brown-800 bg-brown-950/60 p-2.5">
                      <button type="button" onClick={() => void openConversation(conversation.id)} className="min-w-0 flex-1 text-left" disabled={loadingConversation}>
                        <span className="block truncate text-xs font-semibold text-brown-100">{conversation.title}</span>
                        <span className="mt-1 block text-[10px] text-brown-500">{conversation.source === 'recommendation' ? 'Main recommendations' : 'Course agent'} · {new Date(conversation.updated_at).toLocaleDateString()}</span>
                      </button>
                      <button type="button" aria-label="Delete conversation" onClick={() => void deleteConversation(conversation.id)} className="rounded-lg p-1.5 text-brown-500 hover:bg-brown-800 hover:text-red-300">
                        <Trash2 size={14} />
                      </button>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="rounded-xl border border-brown-800 bg-brown-950/60 p-4 text-center text-xs text-brown-400">Recommendation searches and agent chats will appear here.</p>
              )}
            </div>
          ) : (
            <>
              <div ref={scrollRef} className="min-h-0 flex-1 space-y-3 overflow-y-auto bg-slate-950 p-4">
                {messages.length === 0 && (
                  <div className="py-4">
                    <div className="mb-4 flex gap-2 rounded-2xl border border-teal-800/70 bg-teal-950/40 p-3 text-xs leading-relaxed text-brown-200">
                      <BookOpen size={16} className="mt-0.5 shrink-0 text-teal-300" />
                      <p>Ask about courses, skills, difficulty, providers, or your earlier recommendations. Your saved recommendation conversations are available from the history button above.</p>
                    </div>
                    <div className="space-y-2">
                      {quickQuestions.map((question) => (
                        <button key={question} type="button" onClick={() => void sendMessage(question)} className="block w-full rounded-xl border border-brown-800 bg-brown-950/60 px-3 py-2 text-left text-[11px] text-brown-200 transition hover:border-teal-700 hover:text-teal-200">
                          {question}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                {messages.map((message) => (
                  <div key={message.id} className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[90%] rounded-2xl px-3.5 py-3 ${message.role === 'user' ? 'bg-teal-800/70 text-brown-100' : 'border border-brown-800 bg-brown-950/70 text-brown-200'}`}>
                      <p className="whitespace-pre-wrap text-xs leading-relaxed">{message.content}</p>
                      {!!message.courses?.length && (
                        <div className="mt-3 space-y-2">
                          {message.courses.slice(0, 5).map((course) => (
                            <button key={course.course_id} type="button" onClick={() => navigate(`/course/${course.course_id}`)} className="block w-full rounded-xl border border-teal-900/70 bg-slate-950/80 p-2.5 text-left transition hover:border-teal-600">
                              <span className="block text-[11px] font-semibold text-teal-200">{course.course_name}</span>
                              <span className="mt-1 block text-[10px] text-brown-400">
                                {[course.organization, course.difficulty, course.rating ? `${course.rating}/5` : null].filter(Boolean).join(' · ')}
                              </span>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
                {sending && <div className="w-fit rounded-xl border border-brown-800 bg-brown-950/70 px-3 py-2 text-[11px] text-brown-400">Searching the course catalog…</div>}
              </div>
              {error && <p className="border-t border-red-900/60 bg-red-950/40 px-4 py-2 text-[11px] text-red-200">{error}</p>}
              <form onSubmit={handleSubmit} className="border-t border-brown-800 bg-brown-950/80 p-3">
                <div className="flex items-end gap-2 rounded-2xl border border-brown-700 bg-slate-950 p-2 focus-within:border-teal-700">
                  <textarea
                    value={input}
                    onChange={(event) => setInput(event.target.value)}
                    onKeyDown={handleKeyDown}
                    rows={1}
                    maxLength={2000}
                    placeholder="Ask about courses…"
                    aria-label="Ask the course assistant"
                    className="max-h-28 min-h-9 flex-1 resize-y bg-transparent px-2 py-2 text-xs text-brown-100 outline-none placeholder:text-brown-600"
                  />
                  <button type="submit" disabled={!input.trim() || sending} aria-label="Send message" className="rounded-xl bg-teal-700 p-2.5 text-brown-100 transition hover:bg-teal-600 disabled:cursor-not-allowed disabled:opacity-40">
                    <Send size={15} />
                  </button>
                </div>
                <p className="mt-1.5 text-center text-[9px] text-brown-600">Course details come from the catalog; unavailable facts are called out.</p>
              </form>
            </>
          )}
        </section>
      )}

      <button type="button" onClick={isOpen ? () => setIsOpen(false) : openAgent} aria-label="Open course assistant" title="Course assistant" className="flex h-14 w-14 items-center justify-center rounded-full border border-teal-500/60 bg-teal-800 text-brown-100 shadow-[0_12px_36px_rgba(0,0,0,0.65)] transition hover:scale-105 hover:bg-teal-700">
        {isOpen ? <X size={22} /> : <MessageCircle size={22} />}
      </button>
    </div>
  );
}
