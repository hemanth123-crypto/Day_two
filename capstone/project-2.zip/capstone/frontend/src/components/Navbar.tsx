import {
  BookOpen, Brain, Compass, History, Home, LogIn, LogOut, Menu, Shield,
  ShieldCheck, Sparkles, User as UserIcon, X,
} from 'lucide-react';
import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

export default function Navbar() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, isAdmin, isAuthenticated, logout } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);

  const navItems = [
    { name: 'Home', path: '/', icon: Home },
    { name: 'Recommendations', path: '/results', icon: Sparkles },
    { name: 'Skill Gap', path: '/skills', icon: Brain },
    { name: 'Learning Path', path: '/learning-path', icon: Compass },
    { name: 'Evaluation', path: '/evaluation', icon: ShieldCheck },
    { name: 'Courses', path: '/explorer', icon: BookOpen },
    { name: 'Dashboard', path: '/dashboard', icon: History },
    ...(isAdmin ? [{ name: 'Admin Panel', path: '/admin', icon: Shield }] : []),
  ];

  const handleLogout = () => {
    setMobileOpen(false);
    logout();
    navigate('/login');
  };

  const renderLinks = (mobile = false) => (
    <div className="space-y-1">
      {navItems.map((item) => {
        const Icon = item.icon;
        const active = location.pathname === item.path;
        return (
          <Link
            key={item.path}
            to={item.path}
            onClick={() => mobile && setMobileOpen(false)}
            aria-current={active ? 'page' : undefined}
            className={`flex items-center gap-3 rounded-xl px-3.5 py-3 text-sm font-medium transition ${
              active
                ? isAdmin && item.path === '/admin'
                  ? 'border border-amber-300/40 bg-amber-500/20 text-amber-200 shadow-[inset_3px_0_0_#cda78a]'
                  : 'border border-teal-400/40 bg-teal-500/20 text-teal-200 shadow-[inset_3px_0_0_#4bb8ae]'
                : item.path === '/admin'
                  ? 'text-amber-300 hover:bg-amber-500/15 hover:text-amber-200'
                  : 'text-brown-200 hover:bg-slate-800/80 hover:text-teal-200'
            }`}
          >
            <Icon size={18} strokeWidth={1.8} />
            <span>{item.name}</span>
            {active && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-current" />}
          </Link>
        );
      })}
    </div>
  );

  const profile = (
    <div className="border-t border-brown-700/50 p-4">
      {isAuthenticated && user ? (
        <>
          <div className="mb-3 flex min-w-0 items-center gap-3">
            <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-sm font-bold text-brown-100 ${
              isAdmin ? 'bg-gradient-to-br from-violet-600 to-indigo-500' : 'bg-gradient-to-br from-cyan-600 to-blue-500'
            }`}>
              {(user.full_name || user.username).charAt(0).toUpperCase()}
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-semibold text-brown-100">{user.full_name || user.username}</p>
              <p className={`text-xs ${isAdmin ? 'text-violet-300' : 'text-cyan-300'}`}>
                {isAdmin ? 'Administrator' : 'Student'}
              </p>
            </div>
            {isAdmin ? <Shield size={15} className="text-violet-300" /> : <UserIcon size={15} className="text-cyan-300" />}
          </div>
          <button
            type="button"
            onClick={handleLogout}
            className="flex w-full items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm text-brown-200 transition hover:bg-rose-500/10 hover:text-rose-300"
          >
            <LogOut size={17} /> Sign out
          </button>
        </>
      ) : (
        <Link to="/login" className="flex items-center gap-3 rounded-xl px-3.5 py-3 text-sm font-semibold text-cyan-300 hover:bg-cyan-500/10">
          <LogIn size={18} /> Sign in
        </Link>
      )}
    </div>
  );

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 flex-col border-r border-brown-700/50 bg-brown-950/95 md:flex">
        <Link to="/" className="flex h-[88px] items-center gap-3 border-b border-brown-700/50 px-5">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-tr from-cyan-500 to-violet-600 shadow-[0_0_20px_rgba(31,125,120,0.25)]">
            <Sparkles size={21} className="text-brown-100" />
          </div>
          <div>
            <span className="text-[10px] font-bold uppercase tracking-[0.18em] text-cyan-400">Coursera Intelligence</span>
            <h1 className="text-lg font-black tracking-tight text-brown-100">Course Finder</h1>
          </div>
        </Link>

        {isAuthenticated && (
          <div className="mx-4 mt-5 flex items-center gap-2 rounded-xl border border-teal-500/35 bg-teal-500/[0.12] px-3 py-2.5">
            <span className="h-2 w-2 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(31,125,120,0.7)]" />
            <span className="text-xs font-medium text-teal-200">Course engine active</span>
          </div>
        )}

        <nav aria-label="Main navigation" className="flex-1 overflow-y-auto px-3 py-5">
          {isAuthenticated && <p className="mb-3 px-3 text-[10px] font-bold uppercase tracking-[0.18em] text-brown-400">Workspace</p>}
          {isAuthenticated && renderLinks()}
        </nav>
        {profile}
      </aside>

      {/* Mobile header and slide-out sidebar */}
      <header className="fixed inset-x-0 top-0 z-50 flex h-16 items-center justify-between border-b border-brown-700/50 bg-brown-950/95 px-4 backdrop-blur-xl md:hidden">
        <Link to="/" className="flex items-center gap-2.5" onClick={() => setMobileOpen(false)}>
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-tr from-cyan-500 to-violet-600"><Sparkles size={18} /></span>
          <span className="text-sm font-black text-brown-100">Course Finder</span>
        </Link>
        <button
          type="button"
          aria-label={mobileOpen ? 'Close navigation' : 'Open navigation'}
          aria-expanded={mobileOpen}
          onClick={() => setMobileOpen((open) => !open)}
          className="rounded-xl border border-slate-700 bg-slate-900 p-2 text-slate-200"
        >
          {mobileOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </header>

      {mobileOpen && (
        <>
          <button type="button" aria-label="Close navigation" onClick={() => setMobileOpen(false)} className="fixed inset-0 z-40 bg-black/60 md:hidden" />
          <aside className="fixed inset-y-0 left-0 z-50 flex w-[min(19rem,85vw)] flex-col border-r border-brown-700/50 bg-brown-950 shadow-2xl md:hidden">
            <div className="flex h-16 items-center justify-between border-b border-brown-700/50 px-5">
              <span className="text-xs font-bold uppercase tracking-[0.15em] text-cyan-400">Navigation</span>
              <button type="button" aria-label="Close navigation" onClick={() => setMobileOpen(false)} className="rounded-lg p-2 text-slate-400 hover:bg-slate-800 hover:text-brown-100"><X size={18} /></button>
            </div>
            <nav aria-label="Main navigation" className="flex-1 overflow-y-auto px-3 py-5">{isAuthenticated && renderLinks(true)}</nav>
            {profile}
          </aside>
        </>
      )}
    </>
  );
}
