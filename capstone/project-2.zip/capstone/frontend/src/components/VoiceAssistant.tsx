import { Mic, MicOff, Sparkles, Volume2, X } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';

type SpeechRecognitionLike = {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((event: any) => void) | null;
  onerror: ((event: any) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
};

declare global {
  interface Window {
    SpeechRecognition?: new () => SpeechRecognitionLike;
    webkitSpeechRecognition?: new () => SpeechRecognitionLike;
  }
}

const routeMap: Record<string, string> = {
  home: '/',
  dashboard: '/dashboard',
  recommendations: '/results',
  results: '/results',
  skills: '/skills',
  'skill gap': '/skills',
  'learning path': '/learning-path',
  path: '/learning-path',
  evaluation: '/evaluation',
  courses: '/explorer',
  explorer: '/explorer',
  admin: '/admin',
  'admin panel': '/admin',
};

export default function VoiceAssistant() {
  const navigate = useNavigate();
  const recognitionRef = useRef<SpeechRecognitionLike | null>(null);
  const [isOpen, setIsOpen] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [status, setStatus] = useState('Ready');
  const [lastCommand, setLastCommand] = useState('');
  const [isSupported, setIsSupported] = useState(false);

  useEffect(() => {
    const SpeechRecognitionCtor = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognitionCtor) {
      setIsSupported(false);
      setStatus('Speech recognition unavailable in this browser');
      return;
    }

    setIsSupported(true);
    const recognition = new SpeechRecognitionCtor();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onresult = (event: any) => {
      const transcript = Array.from(event.results)
        .map((result: any) => result[0]?.transcript || '')
        .join(' ')
        .trim();

      if (!transcript) {
        return;
      }

      setLastCommand(transcript);
      handleVoiceCommand(transcript);
    };

    recognition.onerror = (event: any) => {
      setStatus(event?.error ? `Voice error: ${event.error}` : 'Voice recognition failed');
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
      setStatus('Ready');
    };

    recognitionRef.current = recognition;

    return () => {
      recognition.stop();
    };
  }, []);

  const speak = (message: string) => {
    if (!('speechSynthesis' in window)) {
      return;
    }

    const utterance = new SpeechSynthesisUtterance(message);
    utterance.rate = 1;
    utterance.pitch = 1;
    utterance.lang = 'en-US';
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
  };

  const handleVoiceCommand = (rawTranscript: string) => {
    const transcript = rawTranscript.toLowerCase().trim();
    const normalized = transcript.replace(/\s+/g, ' ');

    if (!normalized) {
      return;
    }

    const route = Object.keys(routeMap).find((key) => normalized.includes(key));

    if (route) {
      const targetUrl = routeMap[route];
      navigate(targetUrl);
      setStatus(`Opening ${route}`);
      speak(`Opening ${route}.`);
      return;
    }

    if (normalized.includes('search') || normalized.includes('find') || normalized.includes('recommend')) {
      const query = normalized
        .replace(/(search|find|recommend|for|me|courses|course)/gi, '')
        .trim();

      const destinationQuery = query || 'I want to find the best courses for my career goals';
      navigate('/results', { state: { query: destinationQuery } });
      setStatus('Searching for courses');
      speak('Searching for the best course recommendations.');
      return;
    }

    setStatus('Command not recognized');
    speak('I heard you, but I could not match a command in this app.');
  };

  const toggleListening = () => {
    const recognition = recognitionRef.current;
    if (!recognition) {
      setStatus('Voice recognition is unavailable');
      return;
    }

    if (isListening) {
      recognition.stop();
      setIsListening(false);
      setStatus('Stopped listening');
      return;
    }

    try {
      recognition.start();
      setIsListening(true);
      setStatus('Listening...');
      speak('Listening for your command.');
    } catch {
      setStatus('Mic is already active');
    }
  };

  const quickActions = [
    { label: 'Home', onClick: () => navigate('/') },
    { label: 'Results', onClick: () => navigate('/results') },
    { label: 'Path', onClick: () => navigate('/learning-path') },
  ];

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col items-end gap-3">
      {isOpen && (
        <div className="w-72 rounded-2xl border border-teal-200 bg-slate-900 p-3 shadow-[0_20px_50px_rgba(29,101,99,0.18)] backdrop-blur-md">
          <div className="mb-2 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-teal-100 text-teal-700">
                <Sparkles size={16} />
              </div>
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-teal-700">Voice Assist</p>
                <p className="text-xs text-brown-200">Course Finder</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setIsOpen(false)}
              className="rounded-lg p-1.5 text-brown-600 transition hover:bg-brown-100"
              aria-label="Close voice assistant"
            >
              <X size={15} />
            </button>
          </div>

          <div className="grid grid-cols-3 gap-2">
            {quickActions.map((action) => (
              <button
                key={action.label}
                type="button"
                onClick={action.onClick}
                className="rounded-xl border border-teal-200 bg-teal-50 px-2 py-2 text-[11px] font-semibold text-teal-700 transition hover:bg-teal-100"
              >
                {action.label}
              </button>
            ))}
          </div>

          <div className="mt-3 rounded-xl border border-brown-200 bg-brown-800 p-2.5 text-xs text-brown-200">
            <div className="mb-1 flex items-center justify-between">
              <span className="font-semibold">Status</span>
              <span className="text-teal-700">{isListening ? 'Listening' : status}</span>
            </div>
            <p className="line-clamp-3 text-[11px] text-brown-600">
              {lastCommand || 'Try: “open dashboard”, “find data science courses”, or “show learning path”.'}
            </p>
          </div>

          <button
            type="button"
            onClick={toggleListening}
            className={`mt-3 flex w-full items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-semibold text-brown-100 transition ${
              isListening
                ? 'bg-brown-700 hover:bg-brown-800'
                : 'bg-gradient-to-r from-teal-600 to-teal-500 hover:from-teal-700 hover:to-teal-600'
            }`}
          >
            {isListening ? <MicOff size={18} /> : <Mic size={18} />}
            {isListening ? 'Stop listening' : 'Start listening'}
          </button>

          {!isSupported && (
            <p className="mt-2 text-[10px] text-brown-500">
              Voice recognition is not supported in this browser.
            </p>
          )}
        </div>
      )}

      <button
        type="button"
        onClick={() => setIsOpen((open) => !open)}
        aria-label="Toggle voice assistant"
        className="flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-r from-teal-600 to-teal-500 text-brown-100 shadow-[0_18px_35px_rgba(31,125,120,0.4)] transition hover:scale-105 hover:from-teal-700 hover:to-teal-600"
      >
        {isListening ? <Volume2 size={24} className="animate-pulse" /> : <Mic size={24} />}
      </button>
    </div>
  );
}
