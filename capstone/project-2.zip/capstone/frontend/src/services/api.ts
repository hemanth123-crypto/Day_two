import axios from 'axios';

const api = axios.create({
  baseURL: '/api/v1',
  timeout: 60000,
});

// Automatically attach Bearer token from localStorage if present
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('ucf_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export default api;
