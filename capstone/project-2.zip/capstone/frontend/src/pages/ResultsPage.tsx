import { ArrowLeft, BookOpen, Brain, BriefcaseBusiness, Cloud, Compass, Database, Filter, RefreshCw, ShieldCheck, Sparkles, Star, UserCheck } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import CourseDetails from '../components/CourseDetails';
import CourseGrid from '../components/CourseGrid';
import EmptyState from '../components/EmptyState';
import ErrorState from '../components/ErrorState';
import EvaluationModal from '../components/EvaluationModal';
import EvaluationPanel from '../components/EvaluationPanel';
import FilterPanel from '../components/FilterPanel';
import LearningPathTimeline from '../components/LearningPathTimeline';
import LoadingState from '../components/LoadingState';
import SearchForm from '../components/SearchForm';
import SkillGapPanel from '../components/SkillGapPanel';
import api from '../services/api';
import { useAuth } from '../contexts/AuthContext';
import { Course, CourseEvaluation, EvaluationResponse, FilterOptions, RecommendationResponse } from '../types';

export default function ResultsPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user } = useAuth();
  const routeState = (location.state as { query?: string; currentSkills?: string[]; targetCareer?: string } | null) || {};
  const profileLaunch = !routeState.query && !!user?.target_career;
  const profileSkills = routeState.currentSkills ?? (profileLaunch ? user?.current_skills ?? [] : undefined);
  const profileCareer = routeState.targetCareer ?? (profileLaunch ? user?.target_career ?? undefined : undefined);
  const initialQuery = routeState.query || (profileCareer
    ? `${profileSkills?.length ? `I know ${profileSkills.join(', ')}` : 'I am starting with no technical skills'} and want to become a ${profileCareer}. Recommend courses that close my skill gaps.`
    : '');

  const [query, setQuery] = useState(initialQuery);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<RecommendationResponse | null>(null);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState<'courses' | 'skills' | 'path' | 'evaluation'>('courses');
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [filters, setFilters] = useState<FilterOptions>({});
  const [evaluationData, setEvaluationData] = useState<EvaluationResponse | null>(null);
  const [evalLoading, setEvalLoading] = useState(false);
  const [modalEvaluation, setModalEvaluation] = useState<CourseEvaluation | null>(null);

  const fetchEvaluation = async (inputQuery: string, courseId?: string) => {
    setEvalLoading(true);
    try {
      const response = await api.post('/recommendations/evaluate', {
        query: inputQuery,
        course_id: courseId,
        top_k: 8,
      });
      setEvaluationData(response.data);
      return response.data;
    } catch (err: any) {
      console.error('Failed to load evaluation data', err);
    } finally {
      setEvalLoading(false);
    }
  };

  const handleExplainCourse = async (course: Course) => {
    setEvalLoading(true);
    try {
      const response = await api.post('/recommendations/evaluate', {
        query,
        course_id: course.course_id,
        top_k: 1,
      });
      if (response.data?.evaluations && response.data.evaluations.length > 0) {
        setModalEvaluation(response.data.evaluations[0]);
      }
    } catch (err) {
      console.error('Failed to explain course', err);
    } finally {
      setEvalLoading(false);
    }
  };

  const fetchResults = async (
    inputQuery: string,
    currentSkillsOverride?: string[],
    targetCareerOverride?: string,
  ) => {
    if (!inputQuery.trim()) return;
    setLoading(true);
    setError('');
    setEvaluationData(null);

    try {
      const response = await api.post('/recommendations', {
        query: inputQuery,
        current_skills: currentSkillsOverride,
        target_career: targetCareerOverride,
        top_k: 12,
      });

      const data: RecommendationResponse = response.data;
      setResult(data);
      if (data.recommendations && data.recommendations.length > 0) {
        setSelectedCourse(data.recommendations[0]);
      } else {
        setSelectedCourse(null);
      }

      if (activeTab === 'evaluation') {
        fetchEvaluation(inputQuery);
      }

      // Store each completed recommendation query in the signed-in user's history.
      let searchHistoryId: number | undefined;
      try {
        const historyResponse = await api.post('/user/history', {
          query: inputQuery,
          career: data.query?.target_career,
          skills: data.skill_gap?.current_skills?.join(', '),
        });
        searchHistoryId = historyResponse.data?.id;
      } catch {
        // Recommendation results remain available if history storage fails.
      }

      // Keep the recommendation conversation available from the floating course agent.
      try {
        await api.post('/agent/conversations/from-recommendation', {
          query: inputQuery,
          answer: data.llm_answer,
          search_history_id: searchHistoryId,
          courses: (data.recommendations || []).slice(0, 12).map((course) => ({
            course_id: course.course_id,
            course_name: course.course_name,
            organization: course.organization,
            difficulty: course.difficulty,
            rating: course.rating,
            skills: course.skills,
            url: course.url,
          })),
        });
      } catch {
        // Keep the main recommendation page usable if chat history storage fails.
      }
    } catch (err: any) {
      setError(err?.response?.data?.detail || 'Unable to retrieve course recommendations. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (initialQuery) {
      setQuery(initialQuery);
      fetchResults(initialQuery, profileSkills, profileCareer);
    }
  }, [location.key]);

  const handleSearchSubmit = (newQuery: string) => {
    setQuery(newQuery);
    fetchResults(newQuery);
  };

  // Apply client-side filters on recommended courses
  const filteredCourses = (result?.recommendations || []).filter((course) => {
    if (filters.difficulty && course.difficulty?.toLowerCase() !== filters.difficulty.toLowerCase()) {
      return false;
    }
    if (filters.minRating && (course.rating || 0) < filters.minRating) {
      return false;
    }
    if (filters.searchKeyword && filters.searchKeyword.trim()) {
      const kw = filters.searchKeyword.toLowerCase().trim();
      const combined = `${course.course_name} ${course.organization} ${course.skills} ${course.description}`.toLowerCase();
      if (!combined.includes(kw)) {
        return false;
      }
    }
    return true;
  });

  const starterGoals = [
    {
      title: 'Start with Data Science',
      description: 'Build foundations in Python, statistics, and data analysis.',
      query: 'I am new to data science and want to become a Data Scientist. Recommend beginner courses and a learning path.',
      icon: Database,
      color: 'cyan',
    },
    {
      title: 'Grow into Machine Learning',
      description: 'Find the next courses for a machine learning career.',
      query: 'I know Python and want to become a Machine Learning Engineer. Identify my skill gaps and recommend courses.',
      icon: Brain,
      color: 'violet',
    },
    {
      title: 'Explore Cloud Engineering',
      description: 'Discover cloud skills, prerequisites, and courses.',
      query: 'I want to become a Cloud Engineer. Show me the skills I need and build a course path.',
      icon: Cloud,
      color: 'emerald',
    },
  ];

  return (
    <div className="min-h-screen bg-slate-950 px-4 py-8 sm:px-8 text-slate-100">
      <div className="mx-auto max-w-7xl space-y-8">
        {/* Navigation & Search header */}
        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <button
              onClick={() => navigate('/')}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-cyan-400 hover:text-cyan-300 transition"
            >
              <ArrowLeft size={14} /> Back to Search
            </button>
            <span className="text-xs text-slate-400">
              Session Query Mode: <strong className="text-cyan-300">Semantic & Vector Matching</strong>
            </span>
          </div>

        <SearchForm onSubmit={handleSearchSubmit} initialValue={query} loading={loading} />
        </div>

        {!result && !loading && !error && (
          <section className="space-y-7 pt-2">
            <div className="rounded-[28px] border border-cyan-400/15 bg-gradient-to-br from-slate-900/90 via-slate-900/70 to-indigo-950/35 p-6 shadow-[0_24px_80px_rgba(8,47,73,0.24)] sm:p-8">
              <div className="flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
                <div>
                  <span className="inline-flex items-center gap-2 rounded-full border border-cyan-400/20 bg-cyan-400/[0.08] px-3 py-1 text-[11px] font-bold uppercase tracking-[0.16em] text-cyan-700">
                    <Sparkles size={13} /> Personalized course finder
                  </span>
                  <h1 className="mt-4 text-2xl font-black text-brown-100 sm:text-3xl">What do you want to learn next?</h1>
                  <p className="mt-2 max-w-2xl text-sm leading-relaxed text-slate-400">
                    Tell us your career goal and the skills you already have. We will find your gaps and recommend a course path that fits.
                  </p>
                </div>
                <div className="hidden h-20 w-20 shrink-0 items-center justify-center rounded-3xl border border-cyan-300/20 bg-cyan-400/[0.07] text-cyan-700 md:flex">
                  <BriefcaseBusiness size={34} strokeWidth={1.4} />
                </div>
              </div>

              <div className="mt-7 grid gap-3 md:grid-cols-3">
                {starterGoals.map((goal) => {
                  const Icon = goal.icon;
                  const color = goal.color === 'violet'
                    ? 'border-violet-400/20 bg-violet-400/[0.06] text-violet-700 hover:border-violet-300/50'
                    : goal.color === 'emerald'
                      ? 'border-emerald-400/20 bg-emerald-400/[0.05] text-emerald-700 hover:border-emerald-300/50'
                      : 'border-cyan-400/20 bg-cyan-400/[0.05] text-cyan-700 hover:border-cyan-300/50';
                  return (
                    <button
                      key={goal.title}
                      type="button"
                      onClick={() => handleSearchSubmit(goal.query)}
                      className={`group rounded-2xl border p-4 text-left transition duration-300 hover:-translate-y-1 hover:bg-slate-800/80 hover:shadow-xl ${color}`}
                    >
                      <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-950/60 transition group-hover:scale-105">
                        <Icon size={19} />
                      </span>
                      <span className="mt-4 block text-sm font-bold text-brown-100">{goal.title}</span>
                      <span className="mt-1.5 block text-xs leading-relaxed text-slate-400">{goal.description}</span>
                      <span className="mt-4 inline-flex items-center gap-1.5 text-[11px] font-bold text-cyan-700">
                        Build my recommendations <Compass size={13} className="transition group-hover:translate-x-1" />
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="grid gap-3 sm:grid-cols-3">
              {[
                { title: 'See your skill gaps', text: 'Compare your current skills with your chosen career.', icon: Brain, tone: 'text-violet-300 bg-violet-400/10' },
                { title: 'Get relevant courses', text: 'Find courses that teach the skills you need next.', icon: BookOpen, tone: 'text-cyan-300 bg-cyan-400/10' },
                { title: 'Follow a learning path', text: 'Study in prerequisite order, from foundations onward.', icon: Compass, tone: 'text-emerald-300 bg-emerald-400/10' },
              ].map((item) => {
                const Icon = item.icon;
                return (
                  <div key={item.title} className="flex items-start gap-3 rounded-2xl border border-brown-900/[0.07] bg-slate-900/45 p-4">
                    <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${item.tone}`}><Icon size={17} /></span>
                    <div>
                      <h2 className="text-xs font-bold text-slate-100">{item.title}</h2>
                      <p className="mt-1 text-[11px] leading-relaxed text-slate-500">{item.text}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>
        )}

        {/* Loading State */}
        {loading && <LoadingState />}

        {/* Error State */}
        {error && !loading && (
          <ErrorState message={error} onRetry={() => fetchResults(query)} />
        )}

        {/* Results Body */}
        {result && !loading && (
          <div className="space-y-8">
            {/* Query Understanding Banner */}
            <div className="rounded-3xl border border-brown-900/10 bg-gradient-to-r from-slate-900/90 via-slate-900/80 to-cyan-950/30 p-6 shadow-2xl backdrop-blur-xl">
              <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <Sparkles size={16} className="text-cyan-400" />
                    <span className="text-xs font-bold uppercase tracking-widest text-cyan-400">
                      Query Understanding Engine
                    </span>
                  </div>
                  <h2 className="mt-1 text-2xl font-bold text-brown-100">"{query}"</h2>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <div className="rounded-2xl border border-slate-700 bg-slate-800/80 px-4 py-2 text-xs">
                    <span className="text-slate-400 block text-[10px] uppercase tracking-wider">Target Career</span>
                    <strong className="text-cyan-300 text-sm">{result.query?.target_career || 'General Technical'}</strong>
                  </div>
                  <div className="rounded-2xl border border-slate-700 bg-slate-800/80 px-4 py-2 text-xs">
                    <span className="text-slate-400 block text-[10px] uppercase tracking-wider">Difficulty Level</span>
                    <strong className="text-violet-300 text-sm">{result.query?.difficulty || 'Adaptive'}</strong>
                  </div>
                  <div className="rounded-2xl border border-slate-700 bg-slate-800/80 px-4 py-2 text-xs">
                    <span className="text-slate-400 block text-[10px] uppercase tracking-wider">Readiness</span>
                    <strong className="text-emerald-300 text-sm">{Math.round(result.skill_gap?.coverage_percentage || 0)}%</strong>
                  </div>
                </div>
              </div>

              {/* Detected Existing Skills Pills */}
              <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-slate-800/80 pt-3 text-xs text-slate-300">
                <span className="font-semibold text-slate-400">Detected Current Skills:</span>
                {result.query?.existing_skills && result.query.existing_skills.length > 0 ? (
                  result.query.existing_skills.map((s) => (
                    <span key={s} className="rounded-full bg-slate-800 border border-slate-700 px-2.5 py-0.5 text-cyan-700">
                      ✓ {s}
                    </span>
                  ))
                ) : (
                  <span className="text-slate-500 italic">None specified (starting from foundations)</span>
                )}
              </div>
            </div>

            {/* AI-Powered Answer Panel (RAG via OpenRouter LLM) */}
            {result.llm_answer && (
              <div className="rounded-3xl border border-violet-500/30 bg-gradient-to-br from-violet-950/40 via-slate-900/90 to-indigo-950/30 p-6 shadow-2xl backdrop-blur-xl">
                <div className="flex items-center gap-2 mb-3">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-violet-600/30 border border-violet-500/40">
                    <Sparkles size={16} className="text-violet-300" />
                  </div>
                  <div>
                    <span className="text-xs font-bold uppercase tracking-widest text-violet-400">
                      AI-Powered Advisor
                    </span>
                    <span className="ml-2 text-[10px] text-slate-500 font-medium">
                      Powered by OpenRouter LLM
                    </span>
                  </div>
                </div>
                <div className="prose prose-invert prose-sm max-w-none text-slate-200 leading-relaxed">
                  {result.llm_answer.split('\n').map((line, i) => {
                    const trimmed = line.trim();
                    if (!trimmed) return <br key={i} />;
                    if (trimmed.startsWith('### ')) {
                      return <h4 key={i} className="text-base font-bold text-violet-700 mt-4 mb-1">{trimmed.replace('### ', '')}</h4>;
                    }
                    if (trimmed.startsWith('**') && trimmed.endsWith('**')) {
                      return <p key={i} className="font-semibold text-brown-100 mt-2">{trimmed.replace(/\*\*/g, '')}</p>;
                    }
                    if (trimmed.startsWith('- ') || trimmed.startsWith('• ')) {
                      const content = trimmed.replace(/^[-•]\s*/, '');
                      // Bold text within list items
                      const parts = content.split(/(\*\*[^*]+\*\*)/g);
                      return (
                        <div key={i} className="flex items-start gap-2 ml-2 my-0.5">
                          <span className="text-violet-400 mt-0.5">•</span>
                          <span>
                            {parts.map((part, j) =>
                              part.startsWith('**') && part.endsWith('**')
                                ? <strong key={j} className="text-cyan-300">{part.replace(/\*\*/g, '')}</strong>
                                : <span key={j}>{part}</span>
                            )}
                          </span>
                        </div>
                      );
                    }
                    // Inline bold rendering for normal paragraphs
                    const parts = trimmed.split(/(\*\*[^*]+\*\*)/g);
                    return (
                      <p key={i} className="my-1">
                        {parts.map((part, j) =>
                          part.startsWith('**') && part.endsWith('**')
                            ? <strong key={j} className="text-cyan-300">{part.replace(/\*\*/g, '')}</strong>
                            : <span key={j}>{part}</span>
                        )}
                      </p>
                    );
                  })}
                </div>
              </div>
            )}

            {/* View Mode Navigation Tabs */}
            <div className="flex flex-wrap border-b border-slate-800 gap-2">
              <button
                type="button"
                onClick={() => setActiveTab('courses')}
                className={`flex items-center gap-2 px-5 py-3 text-sm font-semibold border-b-2 transition ${
                  activeTab === 'courses'
                    ? 'border-cyan-400 text-cyan-300'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <BookOpen size={16} />
                Recommended Courses ({filteredCourses.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('skills')}
                className={`flex items-center gap-2 px-5 py-3 text-sm font-semibold border-b-2 transition ${
                  activeTab === 'skills'
                    ? 'border-cyan-400 text-cyan-300'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Brain size={16} />
                Skill Gap Analysis ({result.skill_gap?.missing_skills?.length || 0} gaps)
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('path')}
                className={`flex items-center gap-2 px-5 py-3 text-sm font-semibold border-b-2 transition ${
                  activeTab === 'path'
                    ? 'border-cyan-400 text-cyan-300'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Compass size={16} />
                Personalized Learning Path ({result.learning_path?.length || 0} steps)
              </button>
              <button
                type="button"
                onClick={() => {
                  setActiveTab('evaluation');
                  if (!evaluationData) {
                    fetchEvaluation(query);
                  }
                }}
                className={`flex items-center gap-2 px-5 py-3 text-sm font-semibold border-b-2 transition ${
                  activeTab === 'evaluation'
                    ? 'border-cyan-400 text-cyan-300'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <ShieldCheck size={16} />
                Evaluation & Rationale
              </button>
            </div>

            {/* TAB 1: Recommended Courses */}
            {activeTab === 'courses' && (
              <div className="space-y-6">
                {/* Filter Controls */}
                <FilterPanel
                  filters={filters}
                  onChange={setFilters}
                  totalCoursesCount={filteredCourses.length}
                />

                {/* Selected Course Quick View Modal / Card */}
                {selectedCourse && (
                  <div className="mb-6">
                    <CourseDetails
                      course={selectedCourse}
                      targetCareer={result.query?.target_career}
                      onClose={() => setSelectedCourse(null)}
                    />
                  </div>
                )}

                {/* Course Grid */}
                <CourseGrid
                  courses={filteredCourses}
                  selectedCourseId={selectedCourse?.course_id}
                  onSelectCourse={(course) => setSelectedCourse(course)}
                  onExplainCourse={handleExplainCourse}
                />
              </div>
            )}

            {/* TAB 2: Skill Gap Analysis */}
            {activeTab === 'skills' && (
              <div className="space-y-6">
                <SkillGapPanel
                  currentSkills={result.skill_gap?.current_skills || []}
                  missingSkills={result.skill_gap?.missing_skills || []}
                  requiredSkills={result.skill_gap?.required_skills || []}
                  coverage={result.skill_gap?.coverage_percentage || 0}
                  targetCareer={result.query?.target_career || undefined}
                  missingSkillsCourses={result.skill_gap?.missing_skills_courses}
                  onSelectCourse={(course) => {
                    setSelectedCourse(course);
                    setActiveTab('courses');
                  }}
                />
              </div>
            )}

            {/* TAB 3: Personalized Learning Path */}
            {activeTab === 'path' && (
              <div className="space-y-6">
                <div className="rounded-3xl border border-brown-900/10 bg-slate-900/60 p-6 backdrop-blur-xl">
                  <h3 className="text-xl font-bold text-brown-100 mb-1">
                    Structured Curriculum for {result.query?.target_career || 'Target Career'}
                  </h3>
                  <p className="text-xs text-slate-400">
                    Sequenced using topological sort to guarantee each milestone satisfies all course and skill prerequisites.
                  </p>
                </div>

                <LearningPathTimeline steps={result.learning_path || []} />
              </div>
            )}

            {/* TAB 4: Evaluation & Rationale */}
            {activeTab === 'evaluation' && (
              <div className="space-y-6">
                <EvaluationPanel
                  evaluations={evaluationData?.evaluations || []}
                  targetCareer={evaluationData?.target_career || result.query?.target_career || undefined}
                  studentSkills={evaluationData?.student_skills || result.query?.existing_skills}
                  missingSkills={evaluationData?.missing_skills || result.skill_gap?.missing_skills}
                  coveragePct={evaluationData?.career_coverage_pct || result.skill_gap?.coverage_percentage}
                  loading={evalLoading}
                />
              </div>
            )}
          </div>
        )}

        {/* Modal for In-depth Course Evaluation */}
        <EvaluationModal
          isOpen={!!modalEvaluation}
          evaluation={modalEvaluation}
          onClose={() => setModalEvaluation(null)}
          targetCareer={result?.query?.target_career || undefined}
        />
      </div>
    </div>
  );
}
