import { AlertCircle, ArrowRight, Brain, Eye, EyeOff, KeyRound, Loader2, Sparkles, UserPlus } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import SkillSelector from '../components/SkillSelector';
import api from '../services/api';

type Tab = 'login' | 'register';

export default function LoginPage() {
  const { login, register } = useAuth();
  const navigate = useNavigate();
  const [tab, setTab] = useState<Tab>('login');

  // Login form state
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Register form state
  const [regUsername, setRegUsername] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regFullName, setRegFullName] = useState('');
  const [regSkills, setRegSkills] = useState<string[]>([]);
  const [regTargetCareer, setRegTargetCareer] = useState('Data Scientist');
  const [careerOptions, setCareerOptions] = useState<string[]>([
    'Data Scientist', 'Machine Learning Engineer', 'Cloud Engineer',
    'Software Developer', 'Data Analyst', 'Data Engineer',
  ]);

  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get<{ careers: Array<{ career: string }> }>('/skills/careers')
      .then((response) => {
        const options = response.data.careers.map((item) => item.career);
        if (options.length) {
          setCareerOptions(options);
          setRegTargetCareer((selected) => options.includes(selected) ? selected : options[0]);
        }
      })
      .catch(() => undefined);
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await login(loginUsername.trim(), loginPassword);
      const signedInUser = JSON.parse(localStorage.getItem('ucf_user') || '{}');
      if (signedInUser.role === 'admin') {
        navigate('/admin');
      } else if (!signedInUser.target_career) {
        navigate('/skills');
      } else {
        navigate('/');
      }
    } catch (err: any) {
      setError(err?.response?.data?.detail || 'Login failed. Check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!regTargetCareer) {
      setError('Choose a career goal so we can measure your skill gaps.');
      return;
    }
    if (regPassword.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    setLoading(true);
    try {
      await register(
        regUsername.trim(), regEmail.trim(), regPassword,
        regFullName.trim() || undefined, regSkills, regTargetCareer,
      );
      const skillsText = regSkills.length ? `I currently know ${regSkills.join(', ')}.` : 'I am a beginner with no current technical skills.';
      const query = `${skillsText} I want to become a ${regTargetCareer}. Recommend courses that close my skill gaps and build a learning path.`;
      navigate('/results', { state: { query, currentSkills: regSkills, targetCareer: regTargetCareer } });
    } catch (err: any) {
      setError(err?.response?.data?.detail || 'Registration failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center px-4 py-12 relative overflow-x-hidden">
      {/* Background glows */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -left-32 top-10 h-[500px] w-[500px] rounded-full bg-cyan-500/10 blur-[140px]" />
        <div className="absolute right-0 bottom-10 h-[500px] w-[500px] rounded-full bg-violet-600/12 blur-[140px]" />
        <div className="absolute left-1/2 top-1/2 h-96 w-96 -translate-x-1/2 -translate-y-1/2 rounded-full bg-indigo-500/8 blur-[100px]" />
        <svg
          aria-hidden="true"
          className="neural-network absolute inset-0 h-full w-full"
          viewBox="0 0 1440 900"
          preserveAspectRatio="xMidYMid slice"
          fill="none"
        >
          <defs>
            <linearGradient id="neural-line-gradient" x1="0" y1="0" x2="1" y2="1">
              <stop stopColor="#1f7d78" stopOpacity=".65" />
              <stop offset="1" stopColor="#6d4d3a" stopOpacity=".42" />
            </linearGradient>
            <radialGradient id="neural-node-gradient">
              <stop stopColor="#edfdfb" />
              <stop offset=".45" stopColor="#4bb8ae" />
              <stop offset="1" stopColor="#1f7d78" stopOpacity=".12" />
            </radialGradient>
          </defs>
          <g className="neural-lines" stroke="url(#neural-line-gradient)" strokeWidth="1.2">
            <path d="M70 150 210 225 340 130 455 245 590 165 710 260 850 155 1000 245 1165 145 1350 230" />
            <path d="M35 410 190 330 340 430 485 350 625 465 770 355 920 445 1075 350 1235 460 1400 360" />
            <path d="M85 700 230 610 375 735 515 625 660 745 810 625 950 740 1090 620 1250 735 1390 630" />
            <path d="M210 225 190 330 230 610M340 130 340 430 375 735M455 245 485 350 515 625M590 165 625 465 660 745M710 260 770 355 810 625M850 155 920 445 950 740M1000 245 1075 350 1090 620M1165 145 1235 460 1250 735" />
            <path d="M70 150 190 330 340 130 485 350 590 165 770 355 850 155 1075 350 1165 145 1400 360" />
          </g>
          <g>
            {[
              [70,150,4],[210,225,5],[340,130,4],[455,245,5],[590,165,4],[710,260,5],[850,155,4],[1000,245,5],[1165,145,4],[1350,230,5],
              [35,410,4],[190,330,5],[340,430,4],[485,350,5],[625,465,4],[770,355,5],[920,445,4],[1075,350,5],[1235,460,4],[1400,360,5],
              [85,700,4],[230,610,5],[375,735,4],[515,625,5],[660,745,4],[810,625,5],[950,740,4],[1090,620,5],[1250,735,4],[1390,630,5],
            ].map(([cx, cy, r], index) => (
              <circle key={index} className="neural-node" style={{ animationDelay: `${(index % 7) * -0.45}s` }} cx={cx} cy={cy} r={r} fill="url(#neural-node-gradient)" />
            ))}
          </g>
          <g className="neural-particles" fill="#7dd7ca">
            <circle r="3.5"><animateMotion dur="8s" repeatCount="indefinite" path="M70 150 210 225 340 130 455 245 590 165 710 260 850 155 1000 245 1165 145 1350 230" /></circle>
            <circle r="3"><animateMotion dur="10s" begin="-4s" repeatCount="indefinite" path="M35 410 190 330 340 430 485 350 625 465 770 355 920 445 1075 350 1235 460 1400 360" /></circle>
            <circle r="3.5"><animateMotion dur="9s" begin="-3s" repeatCount="indefinite" path="M85 700 230 610 375 735 515 625 660 745 810 625 950 740 1090 620 1250 735 1390 630" /></circle>
            <circle r="3"><animateMotion dur="7s" begin="-2s" repeatCount="indefinite" path="M70 150 190 330 340 430 485 350 590 165 770 355 920 445 1075 350 1165 145 1400 360" /></circle>
            <circle r="3"><animateMotion dur="9s" begin="-6s" repeatCount="indefinite" path="M1350 230 1165 145 1000 245 850 155 710 260 590 165 455 245 340 130 210 225 70 150" /></circle>
            <circle r="2.5"><animateMotion dur="11s" begin="-5s" repeatCount="indefinite" path="M1390 630 1250 735 1090 620 950 740 810 625 660 745 515 625 375 735 230 610 85 700" /></circle>
          </g>
        </svg>
      </div>

      <div className="relative z-10 w-full max-w-md">
        {/* Logo */}
        <div className="mb-8 text-center">
          <div className="auth-logo-motion mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-3xl bg-gradient-to-tr from-cyan-500 to-violet-600 shadow-[0_0_40px_rgba(31,125,120,0.4)]">
            <Sparkles size={30} className="text-brown-100" />
          </div>
          <span className="text-xs font-bold uppercase tracking-widest text-cyan-400">Coursera Intelligence</span>
          <h1 className="mt-1 text-2xl font-black text-brown-100">University Course Finder</h1>
          <p className="mt-1 text-sm text-slate-400">Sign in to your personalized learning workspace</p>
        </div>

        {/* Card */}
        <div className="rounded-3xl border border-brown-900/10 bg-slate-900/80 p-8 shadow-2xl backdrop-blur-2xl">
          {/* Tabs */}
          <div className="mb-6 flex rounded-2xl border border-slate-800 bg-slate-950/60 p-1">
            {(['login', 'register'] as Tab[]).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => { setTab(t); setError(''); }}
                className={`flex-1 rounded-xl py-2 text-sm font-semibold transition ${
                  tab === t
                    ? 'bg-gradient-to-r from-cyan-500/25 to-violet-500/25 text-brown-100 shadow border border-cyan-400/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {t === 'login' ? 'Sign In' : 'Register'}
              </button>
            ))}
          </div>

          {/* Error banner */}
          {error && (
            <div className="mb-5 flex items-start gap-3 rounded-2xl border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-300">
              <AlertCircle size={16} className="mt-0.5 flex-shrink-0" />
              <p>{error}</p>
            </div>
          )}

          {/* LOGIN FORM */}
          {tab === 'login' && (
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Username
                </label>
                <input
                  id="login-username"
                  type="text"
                  required
                  autoComplete="username"
                  value={loginUsername}
                  onChange={(e) => setLoginUsername(e.target.value)}
                  placeholder="e.g. admin"
                  className="w-full rounded-xl border border-slate-700 bg-slate-800/70 px-4 py-3 text-sm text-brown-100 placeholder-slate-500 focus:border-cyan-400/60 focus:outline-none focus:ring-2 focus:ring-cyan-400/20 transition"
                />
              </div>

              <div>
                <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Password
                </label>
                <div className="relative">
                  <input
                    id="login-password"
                    type={showPass ? 'text' : 'password'}
                    required
                    autoComplete="current-password"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full rounded-xl border border-slate-700 bg-slate-800/70 px-4 py-3 pr-11 text-sm text-brown-100 placeholder-slate-500 focus:border-cyan-400/60 focus:outline-none focus:ring-2 focus:ring-cyan-400/20 transition"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPass(!showPass)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition"
                  >
                    {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>

              <button
                id="login-submit-btn"
                type="submit"
                disabled={loading}
                className="mt-2 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-500 to-violet-600 py-3 text-sm font-bold text-brown-100 shadow-[0_0_24px_rgba(31,125,120,0.3)] transition hover:opacity-90 disabled:opacity-60"
              >
                {loading ? <Loader2 size={16} className="animate-spin" /> : <KeyRound size={16} />}
                {loading ? 'Signing in...' : 'Sign In'}
              </button>

              {/* Default accounts hint */}
              <div className="mt-4 rounded-2xl border border-slate-700/60 bg-slate-800/40 p-4 space-y-2">
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Demo Accounts</p>
                <div className="grid grid-cols-1 gap-2 text-xs">
                  <div className="rounded-xl border border-cyan-500/30 bg-cyan-500/10 p-2.5">
                    <p className="font-bold text-cyan-300">Student</p>
                    <p className="text-slate-400 mt-0.5">student / student123</p>
                  </div>
                </div>
              </div>
            </form>
          )}

          {/* REGISTER FORM */}
          {tab === 'register' && (
            <form onSubmit={handleRegister} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">
                    Username *
                  </label>
                  <input
                    id="reg-username"
                    type="text"
                    required
                    minLength={3}
                    value={regUsername}
                    onChange={(e) => setRegUsername(e.target.value)}
                    placeholder="john_doe"
                    className="w-full rounded-xl border border-slate-700 bg-slate-800/70 px-3 py-2.5 text-sm text-brown-100 placeholder-slate-500 focus:border-cyan-400/60 focus:outline-none focus:ring-2 focus:ring-cyan-400/20 transition"
                  />
                </div>
                <div>
                  <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">
                    Full Name
                  </label>
                  <input
                    id="reg-fullname"
                    type="text"
                    value={regFullName}
                    onChange={(e) => setRegFullName(e.target.value)}
                    placeholder="John Doe"
                    className="w-full rounded-xl border border-slate-700 bg-slate-800/70 px-3 py-2.5 text-sm text-brown-100 placeholder-slate-500 focus:border-cyan-400/60 focus:outline-none focus:ring-2 focus:ring-cyan-400/20 transition"
                  />
                </div>
              </div>

              <div>
                <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Email *
                </label>
                <input
                  id="reg-email"
                  type="email"
                  required
                  value={regEmail}
                  onChange={(e) => setRegEmail(e.target.value)}
                  placeholder="john@university.edu"
                  className="w-full rounded-xl border border-slate-700 bg-slate-800/70 px-4 py-3 text-sm text-brown-100 placeholder-slate-500 focus:border-cyan-400/60 focus:outline-none focus:ring-2 focus:ring-cyan-400/20 transition"
                />
              </div>

              <div>
                <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Password *
                </label>
                <div className="relative">
                  <input
                    id="reg-password"
                    type={showPass ? 'text' : 'password'}
                    required
                    minLength={6}
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="Min 6 characters"
                    className="w-full rounded-xl border border-slate-700 bg-slate-800/70 px-4 py-3 pr-11 text-sm text-brown-100 placeholder-slate-500 focus:border-cyan-400/60 focus:outline-none focus:ring-2 focus:ring-cyan-400/20 transition"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPass(!showPass)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition"
                  >
                    {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>

              <div>
                <label htmlFor="reg-career" className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Career Goal *
                </label>
                <select
                  id="reg-career"
                  required
                  value={regTargetCareer}
                  onChange={(e) => setRegTargetCareer(e.target.value)}
                  className="w-full rounded-xl border border-slate-700 bg-slate-800/70 px-4 py-3 text-sm text-brown-100 focus:border-cyan-400/60 focus:outline-none focus:ring-2 focus:ring-cyan-400/20"
                >
                  {careerOptions.map((career) => <option key={career} value={career}>{career}</option>)}
                </select>
              </div>

              <div className="rounded-2xl border border-slate-700/70 bg-slate-950/40 p-4">
                <p className="mb-3 text-xs leading-relaxed text-slate-400">
                  Tell us what you already know. Leave this empty if you are starting from the beginning.
                </p>
                <SkillSelector
                  label="Skills you already have"
                  selectedSkills={regSkills}
                  onChange={setRegSkills}
                />
              </div>

              <button
                id="reg-submit-btn"
                type="submit"
                disabled={loading}
                className="mt-2 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-500 to-violet-600 py-3 text-sm font-bold text-brown-100 shadow-[0_0_24px_rgba(31,125,120,0.3)] transition hover:opacity-90 disabled:opacity-60"
              >
                {loading ? <Loader2 size={16} className="animate-spin" /> : <UserPlus size={16} />}
                {loading ? 'Creating account...' : 'Create Account'}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
