import { BookmarkIcon, BriefcaseBusiness, History, MessageSquare, Star, Trash2, Brain } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import api from '../services/api';
import { FeedbackItem, UserSearchHistoryItem, UserBookmark } from '../types';

export default function DashboardPage() {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();
  const [history, setHistory] = useState<UserSearchHistoryItem[]>([]);
  const [bookmarks, setBookmarks] = useState<UserBookmark[]>([]);
  const [feedback, setFeedback] = useState<FeedbackItem[]>([]);

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    // Load user-isolated search history from API (not localStorage)
    const loadHistory = async () => {
      try {
        const res = await api.get<UserSearchHistoryItem[]>('/user/history');
        setHistory(res.data);
      } catch {
        setHistory([]);
      }
    };

    // Load user bookmarks
    const loadBookmarks = async () => {
      try {
        const res = await api.get<UserBookmark[]>('/user/bookmarks');
        setBookmarks(res.data);
      } catch {
        setBookmarks([]);
      }
    };

    // Load only this user's feedback, never the platform-wide feedback feed.
    const loadFeedback = async () => {
      try {
        const response = await api.get<FeedbackItem[]>('/user/feedback');
        setFeedback(response.data);
      } catch {
        setFeedback([]);
      }
    };

    loadHistory();
    loadBookmarks();
    loadFeedback();
  }, [isAuthenticated]);

  const clearHistory = async () => {
    try {
      await api.delete('/user/history');
      setHistory([]);
    } catch {
      // silent
    }
  };

  const removeBookmark = async (courseId: string) => {
    try {
      await api.delete(`/user/bookmarks/${courseId}`);
      setBookmarks((prev) => prev.filter((b) => b.course_id !== courseId));
    } catch {
      // silent
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 px-4 py-10 sm:px-8 text-slate-100">
      <div className="mx-auto max-w-6xl space-y-8">
        {/* Header */}
        <div className="flex items-start gap-4">
          <div className={`flex h-14 w-14 flex-shrink-0 items-center justify-center rounded-3xl text-xl font-black text-brown-100 ${
            user?.role === 'admin'
              ? 'bg-gradient-to-tr from-violet-600 to-indigo-500'
              : 'bg-gradient-to-tr from-cyan-500 to-blue-600'
          }`}>
            {(user?.full_name || user?.username || 'U').charAt(0).toUpperCase()}
          </div>
          <div>
            <h1 className="text-3xl sm:text-4xl font-black text-brown-100">
              {user?.full_name || user?.username}'s Dashboard
            </h1>
            <p className="mt-1 text-sm text-slate-400">
              Your learning profile, recent searches, and saved courses.
            </p>
          </div>
        </div>

        {!user?.target_career && (
          <div className="flex flex-col gap-4 rounded-2xl border border-cyan-500/25 bg-cyan-500/[0.07] p-5 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h2 className="text-sm font-bold text-cyan-700">Finish your learning profile</h2>
              <p className="mt-1 text-xs text-slate-400">Add the skills you already know and choose a career goal to get accurate readiness and course recommendations.</p>
            </div>
            <button
              type="button"
              onClick={() => navigate('/skills')}
              className="shrink-0 rounded-xl bg-cyan-400 px-4 py-2.5 text-xs font-bold text-brown-100 transition hover:bg-cyan-300"
            >
              Set up profile
            </button>
          </div>
        )}

        {/* Personal learning profile summary */}
        <div className="grid grid-cols-2 gap-4 xl:grid-cols-4">
          <div className="rounded-3xl border border-brown-900/10 bg-slate-900/70 p-5 backdrop-blur-xl">
            <span className="block text-xs uppercase tracking-wider text-slate-400">Searches</span>
            <span className="mt-1 block text-3xl font-black text-cyan-300">{history.length}</span>
            <span className="text-[10px] text-slate-500">Your recent learning goals</span>
          </div>
          <div className="rounded-3xl border border-brown-900/10 bg-slate-900/70 p-5 backdrop-blur-xl">
            <span className="block text-xs uppercase tracking-wider text-slate-400">Saved Courses</span>
            <span className="mt-1 block text-3xl font-black text-amber-300">{bookmarks.length}</span>
            <span className="text-[10px] text-slate-500">In your personal library</span>
          </div>
          <div className="rounded-3xl border border-brown-900/10 bg-slate-900/70 p-5 backdrop-blur-xl">
            <span className="flex items-center gap-2 text-xs uppercase tracking-wider text-slate-400"><Brain size={14} /> Current Skills</span>
            <span className="mt-1 block text-3xl font-black text-emerald-300">{user?.current_skills?.length || 0}</span>
            <span className="text-[10px] text-slate-500">Used in your skill-gap analysis</span>
          </div>
          <div className="rounded-3xl border border-brown-900/10 bg-slate-900/70 p-5 backdrop-blur-xl">
            <span className="flex items-center gap-2 text-xs uppercase tracking-wider text-slate-400"><BriefcaseBusiness size={14} /> Career Goal</span>
            <span className="mt-2 block truncate text-lg font-black text-violet-300">{user?.target_career || 'Not set'}</span>
            <span className="text-[10px] text-slate-500">Your recommendation target</span>
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          {/* Search History (User-isolated from API) */}
          <div className="rounded-3xl border border-brown-900/10 bg-slate-900/70 p-6 backdrop-blur-xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <History size={18} className="text-cyan-400" />
                <h3 className="text-base font-bold text-brown-100">My Search History</h3>
              </div>
              {history.length > 0 && (
                <button
                  type="button"
                  onClick={clearHistory}
                  className="flex items-center gap-1 text-xs text-rose-400 hover:text-rose-300 transition"
                >
                  <Trash2 size={13} /> Clear
                </button>
              )}
            </div>

            {history.length === 0 ? (
              <p className="text-xs text-slate-500 py-6 text-center">
                No searches yet. Go to the Home page and start exploring!
              </p>
            ) : (
              <div className="space-y-2.5 max-h-96 overflow-y-auto pr-1">
                {history.map((h) => (
                  <div
                    key={h.id}
                    onClick={() => navigate('/results', { state: { query: h.query } })}
                    className="group cursor-pointer rounded-2xl border border-slate-800 bg-slate-950/60 p-3.5 transition hover:border-cyan-400/50 hover:bg-slate-900"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <p className="text-xs font-semibold text-brown-100 group-hover:text-cyan-700 transition">
                        "{h.query}"
                      </p>
                      {h.career && (
                        <span className="rounded-full bg-slate-800 px-2 py-0.5 text-[10px] text-cyan-300 flex-shrink-0">
                          {h.career}
                        </span>
                      )}
                    </div>
                    <span className="mt-1.5 block text-[10px] text-slate-500">
                      {new Date(h.created_at).toLocaleDateString()} at{' '}
                      {new Date(h.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Bookmarks (User-isolated) */}
          <div className="rounded-3xl border border-brown-900/10 bg-slate-900/70 p-6 backdrop-blur-xl space-y-4">
            <div className="flex items-center gap-2">
              <BookmarkIcon size={18} className="text-amber-400" />
              <h3 className="text-base font-bold text-brown-100">My Saved Courses</h3>
            </div>

            {bookmarks.length === 0 ? (
              <p className="text-xs text-slate-500 py-6 text-center">
                No bookmarks yet. Browse and save courses from the Courses section.
              </p>
            ) : (
              <div className="space-y-2.5 max-h-96 overflow-y-auto pr-1">
                {bookmarks.map((bm) => (
                  <div
                    key={bm.id}
                    className="rounded-2xl border border-slate-800 bg-slate-950/60 p-3.5 flex items-center justify-between gap-3"
                  >
                    <div
                      className="flex-1 cursor-pointer"
                      onClick={() => navigate(`/course/${bm.course_id}`)}
                    >
                      <p className="text-xs font-semibold text-brown-100 hover:text-amber-700 transition">
                        {bm.course_name || bm.course_id}
                      </p>
                      <div className="mt-1 flex items-center gap-2 text-[10px] text-slate-500">
                        {bm.organization && <span>{bm.organization}</span>}
                        {bm.difficulty && (
                          <>
                            <span>Â·</span>
                            <span>{bm.difficulty}</span>
                          </>
                        )}
                        {bm.rating && (
                          <>
                            <span>Â·</span>
                            <span className="text-amber-400">â˜… {bm.rating}</span>
                          </>
                        )}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => removeBookmark(bm.course_id)}
                      className="flex-shrink-0 rounded-xl border border-slate-700 p-1.5 text-slate-500 hover:border-rose-500/40 hover:text-rose-400 transition"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Recent Student Feedback */}
          <div className="rounded-3xl border border-brown-900/10 bg-slate-900/70 p-6 backdrop-blur-xl space-y-4 lg:col-span-2">
            <div className="flex items-center gap-2">
              <MessageSquare size={18} className="text-amber-400" />
              <h3 className="text-base font-bold text-brown-100">Latest Recommendation Feedback</h3>
            </div>

            {feedback.length > 0 ? (
              <div className="grid sm:grid-cols-2 gap-2.5">
                {feedback.slice(0, 6).map((fb) => (
                  <div
                    key={fb.id}
                    className="rounded-2xl border border-slate-800 bg-slate-950/60 p-3.5"
                  >
                    <div className="mb-3">
                      {fb.course_id ? (
                        <button
                          type="button"
                          onClick={() => navigate(`/course/${fb.course_id}`)}
                          className="text-left text-sm font-semibold text-brown-100 hover:text-cyan-700"
                          title={`Course ID: ${fb.course_id}`}
                        >
                          {fb.course_name || `Course ${fb.course_id}`}
                        </button>
                      ) : (
                        <p className="text-sm font-semibold text-brown-100">General Recommendation</p>
                      )}
                      {fb.course_id && <p className="mt-0.5 text-[10px] text-slate-500">Course ID: {fb.course_id}</p>}
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1 text-amber-300">
                        {[...Array(fb.rating)].map((_, idx) => (
                          <Star key={idx} size={13} className="fill-amber-400 text-amber-400" />
                        ))}
                      </div>
                      <span
                        className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${
                          fb.useful
                            ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30'
                            : 'bg-rose-500/10 text-rose-300 border border-rose-500/30'
                        }`}
                      >
                        {fb.useful ? 'Useful' : 'Not Useful'}
                      </span>
                    </div>
                    {fb.comment && (
                      <p className="mt-2 text-xs text-slate-300 italic">"{fb.comment}"</p>
                    )}
                    <div className="mt-2 flex flex-wrap items-center gap-x-1 text-[10px] text-slate-500">
                      <span>{fb.created_at ? new Date(fb.created_at).toLocaleDateString() : 'Just now'}</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-500 py-6 text-center">
                No feedback received yet. Submit feedback on any recommended course!
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
