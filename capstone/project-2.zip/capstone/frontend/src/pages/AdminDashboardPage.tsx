import {
  BarChart3, BookmarkIcon, Clock, Database, History, Loader2,
  MessageSquare, RefreshCw, Shield, ShieldAlert, Trash2, UserCheck, Users, Zap,
} from 'lucide-react';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import api from '../services/api';
import { AdminStats, AdminUserItem } from '../types';

export default function AdminDashboardPage() {
  const { user, isAdmin } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [users, setUsers] = useState<AdminUserItem[]>([]);
  const [loadingStats, setLoadingStats] = useState(true);
  const [loadingUsers, setLoadingUsers] = useState(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'users'>('overview');
  const [updatingId, setUpdatingId] = useState<number | null>(null);

  useEffect(() => {
    if (!isAdmin) {
      navigate('/');
      return;
    }
    loadStats();
    loadUsers();
  }, [isAdmin]);

  const loadStats = async () => {
    setLoadingStats(true);
    try {
      const res = await api.get<AdminStats>('/admin/stats');
      setStats(res.data);
    } finally {
      setLoadingStats(false);
    }
  };

  const loadUsers = async () => {
    setLoadingUsers(true);
    try {
      const res = await api.get<AdminUserItem[]>('/admin/users');
      setUsers(res.data);
    } finally {
      setLoadingUsers(false);
    }
  };

  const toggleRole = async (u: AdminUserItem) => {
    if (u.id === user?.id) return; // can't demote yourself
    const newRole = u.role === 'admin' ? 'user' : 'admin';
    setUpdatingId(u.id);
    try {
      await api.patch(`/admin/users/${u.id}/role`, { role: newRole });
      setUsers((prev) => prev.map((x) => x.id === u.id ? { ...x, role: newRole } : x));
    } catch {
      alert('Role update failed.');
    } finally {
      setUpdatingId(null);
    }
  };

  const deleteUser = async (u: AdminUserItem) => {
    if (u.id === user?.id) return;
    if (!window.confirm(`Delete user "${u.username}"? This is irreversible.`)) return;
    try {
      await api.delete(`/admin/users/${u.id}`);
      setUsers((prev) => prev.filter((x) => x.id !== u.id));
    } catch {
      alert('Failed to delete user.');
    }
  };

  const statCards = stats
    ? [
        { label: 'Total Users', value: stats.total_users, icon: Users, color: 'cyan' },
        { label: 'Admin Accounts', value: stats.admin_count, icon: Shield, color: 'violet' },
        { label: 'Student Accounts', value: stats.user_count, icon: UserCheck, color: 'emerald' },
        { label: 'Total Searches', value: stats.total_searches, icon: History, color: 'amber' },
        { label: 'Total Bookmarks', value: stats.total_bookmarks, icon: BookmarkIcon, color: 'sky' },
        { label: 'Total Feedback', value: stats.total_feedback, icon: MessageSquare, color: 'rose' },
        { label: 'Courses in DB', value: stats.total_courses, icon: Database, color: 'indigo' },
        { label: 'Vector Engine', value: 'FAISS', icon: Zap, color: 'fuchsia' },
      ]
    : [];

  const colorMap: Record<string, string> = {
    cyan: 'text-cyan-300',
    violet: 'text-violet-300',
    emerald: 'text-emerald-300',
    amber: 'text-amber-300',
    sky: 'text-sky-300',
    rose: 'text-rose-300',
    indigo: 'text-indigo-300',
    fuchsia: 'text-fuchsia-300',
  };

  return (
    <div className="min-h-screen bg-slate-950 px-4 py-10 sm:px-8 text-slate-100">
      <div className="mx-auto max-w-7xl space-y-8">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <ShieldAlert size={22} className="text-violet-400" />
              <span className="text-xs font-bold uppercase tracking-widest text-violet-400">Admin Control Panel</span>
            </div>
            <h1 className="text-3xl font-black text-brown-100">System Administration</h1>
            <p className="mt-1 text-sm text-slate-400">
              Manage all users, monitor activity metrics, and control access roles.
            </p>
          </div>
          <button
            type="button"
            onClick={() => { loadStats(); loadUsers(); }}
            className="flex items-center gap-2 rounded-2xl border border-slate-700 bg-slate-800/60 px-4 py-2 text-sm text-slate-300 hover:text-brown-100 hover:border-slate-600 transition"
          >
            <RefreshCw size={14} />
            Refresh
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 border-b border-slate-800 pb-0">
          {(['overview', 'users'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setActiveTab(t)}
              className={`px-5 py-2.5 text-sm font-semibold rounded-t-xl transition ${
                activeTab === t
                  ? 'bg-slate-800 text-brown-100 border-t border-l border-r border-slate-700'
                  : 'text-slate-500 hover:text-slate-300'
              }`}
            >
              {t === 'overview' ? <span className="flex items-center gap-2"><BarChart3 size={14} /> Overview</span>
                : <span className="flex items-center gap-2"><Users size={14} /> Users ({users.length})</span>}
            </button>
          ))}
        </div>

        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {loadingStats ? (
              <div className="flex items-center justify-center py-16">
                <Loader2 size={32} className="animate-spin text-cyan-400" />
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {statCards.map((card) => {
                  const Icon = card.icon;
                  return (
                    <div key={card.label} className="rounded-3xl border border-brown-900/8 bg-slate-900/70 p-5 backdrop-blur-xl">
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-xs uppercase tracking-wider text-slate-400">{card.label}</span>
                        <Icon size={16} className={colorMap[card.color]} />
                      </div>
                      <span className={`text-2xl font-black ${colorMap[card.color]}`}>
                        {card.value}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Users Tab */}
        {activeTab === 'users' && (
          <div className="rounded-3xl border border-brown-900/8 bg-slate-900/70 overflow-hidden backdrop-blur-xl">
            {loadingUsers ? (
              <div className="flex items-center justify-center py-16">
                <Loader2 size={32} className="animate-spin text-cyan-400" />
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-slate-800 text-left text-xs uppercase tracking-wider text-slate-500">
                      <th className="px-5 py-4">User</th>
                      <th className="px-4 py-4">Role</th>
                      <th className="px-4 py-4 hidden md:table-cell">
                        <span className="flex items-center gap-1"><History size={11} /> Searches</span>
                      </th>
                      <th className="px-4 py-4 hidden md:table-cell">
                        <span className="flex items-center gap-1"><BookmarkIcon size={11} /> Bookmarks</span>
                      </th>
                      <th className="px-4 py-4 hidden lg:table-cell">
                        <span className="flex items-center gap-1"><MessageSquare size={11} /> Feedback</span>
                      </th>
                      <th className="px-4 py-4 hidden lg:table-cell">
                        <span className="flex items-center gap-1"><Clock size={11} /> Joined</span>
                      </th>
                      <th className="px-5 py-4">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {users.map((u) => (
                      <tr key={u.id} className="hover:bg-slate-800/30 transition">
                        <td className="px-5 py-4">
                          <div>
                            <p className="font-semibold text-brown-100">{u.full_name || u.username}</p>
                            <p className="text-xs text-slate-500">@{u.username} · {u.email}</p>
                          </div>
                        </td>
                        <td className="px-4 py-4">
                          <span className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-bold border ${
                            u.role === 'admin'
                              ? 'border-violet-500/40 bg-violet-500/15 text-violet-300'
                              : 'border-cyan-500/40 bg-cyan-500/15 text-cyan-300'
                          }`}>
                            {u.role === 'admin' ? <Shield size={11} /> : <UserCheck size={11} />}
                            {u.role}
                          </span>
                        </td>
                        <td className="px-4 py-4 hidden md:table-cell text-slate-300">{u.search_count}</td>
                        <td className="px-4 py-4 hidden md:table-cell text-slate-300">{u.bookmark_count}</td>
                        <td className="px-4 py-4 hidden lg:table-cell text-slate-300">{u.feedback_count}</td>
                        <td className="px-4 py-4 hidden lg:table-cell text-slate-500 text-xs">
                          {new Date(u.created_at).toLocaleDateString()}
                        </td>
                        <td className="px-5 py-4">
                          <div className="flex items-center gap-2">
                            {/* Toggle role */}
                            <button
                              type="button"
                              onClick={() => toggleRole(u)}
                              disabled={u.id === user?.id || updatingId === u.id}
                              title={u.id === user?.id ? "Cannot change your own role" : `Switch to ${u.role === 'admin' ? 'user' : 'admin'}`}
                              className={`rounded-xl px-3 py-1.5 text-xs font-semibold transition disabled:opacity-40 disabled:cursor-not-allowed ${
                                u.role === 'admin'
                                  ? 'border border-amber-500/40 bg-amber-500/10 text-amber-300 hover:bg-amber-500/20'
                                  : 'border border-violet-500/40 bg-violet-500/10 text-violet-300 hover:bg-violet-500/20'
                              }`}
                            >
                              {updatingId === u.id
                                ? <Loader2 size={12} className="animate-spin" />
                                : u.role === 'admin' ? '→ User' : '→ Admin'}
                            </button>
                            {/* Delete */}
                            <button
                              type="button"
                              onClick={() => deleteUser(u)}
                              disabled={u.id === user?.id}
                              title={u.id === user?.id ? "Cannot delete yourself" : "Delete user"}
                              className="rounded-xl border border-rose-500/30 bg-rose-500/10 p-1.5 text-rose-400 hover:bg-rose-500/20 transition disabled:opacity-30 disabled:cursor-not-allowed"
                            >
                              <Trash2 size={13} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
