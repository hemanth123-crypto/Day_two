import { Route, Routes, useLocation } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import Navbar from './components/Navbar';
import ProtectedRoute from './components/ProtectedRoute';
import VoiceAssistant from './components/VoiceAssistant';
import CourseAgent from './components/CourseAgent';
import LoginPage from './pages/LoginPage';
import AdminDashboardPage from './pages/AdminDashboardPage';
import CourseDetailPage from './pages/CourseDetailPage';
import CoursesExplorerPage from './pages/CoursesExplorerPage';
import DashboardPage from './pages/DashboardPage';
import HomePage from './pages/HomePage';
import LearningPathPage from './pages/LearningPathPage';
import ResultsPage from './pages/ResultsPage';
import SkillGapPage from './pages/SkillGapPage';
import EvaluationPage from './pages/EvaluationPage';

export default function App() {
  const location = useLocation();
  const isLoginPage = location.pathname === '/login' || location.pathname === '/register';

  return (
    <AuthProvider>
      <div className="min-h-screen bg-slate-950 text-slate-50 font-sans antialiased">
        {!isLoginPage && <Navbar />}
        <main className={isLoginPage ? 'min-h-screen bg-transparent' : 'min-h-screen bg-transparent pt-16 md:ml-64 md:pt-0'}>
          <Routes>
            {/* Public: Login */}
            <Route path="/login" element={<LoginPage />} />

            {/* Protected: All app pages require auth */}
            <Route path="/" element={<ProtectedRoute><HomePage /></ProtectedRoute>} />
            <Route path="/results" element={<ProtectedRoute><ResultsPage /></ProtectedRoute>} />
            <Route path="/skills" element={<ProtectedRoute><SkillGapPage /></ProtectedRoute>} />
            <Route path="/learning-path" element={<ProtectedRoute><LearningPathPage /></ProtectedRoute>} />
            <Route path="/evaluation" element={<ProtectedRoute><EvaluationPage /></ProtectedRoute>} />
            <Route path="/explorer" element={<ProtectedRoute><CoursesExplorerPage /></ProtectedRoute>} />
            <Route path="/dashboard" element={<ProtectedRoute><DashboardPage /></ProtectedRoute>} />
            <Route path="/course/:courseId" element={<ProtectedRoute><CourseDetailPage /></ProtectedRoute>} />

            {/* Admin-only */}
            <Route path="/admin" element={<ProtectedRoute adminOnly><AdminDashboardPage /></ProtectedRoute>} />
          </Routes>
        </main>
        {!isLoginPage && (
          <>
            <VoiceAssistant />
            <CourseAgent />
            <footer className="border-t border-slate-300/10 bg-slate-900/80 py-6 text-center text-xs text-slate-300 backdrop-blur-sm md:ml-64">
              <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-6 sm:flex-row">
                <p>© 2026 University Course Finder — Intelligent Course Discovery & Learning Path Engine</p>
                <p className="text-cyan-300/90">Built with FastAPI • FAISS Vector Engine • React • Tailwind</p>
              </div>
            </footer>
          </>
        )}
      </div>
    </AuthProvider>
  );
}
