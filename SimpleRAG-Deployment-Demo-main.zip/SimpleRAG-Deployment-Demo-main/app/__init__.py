"""BasicRAG FastAPI application package."""
