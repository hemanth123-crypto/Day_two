"""Service layer for BasicRAG."""
